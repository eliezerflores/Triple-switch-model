function fig = plot(obj, varargin)
%PLOT plot the behaviour network on the normal node layout
%         100     110
% 000     010     011     111
%         001     101
% IMPORTANT NOTE:
% the D-switch status works the opposite way to the RK- and T-switch
% statuses so when it's in the 1 configuration, it should be plotted as
% off. When the D-switch is in the 0 configuration, it should be plotted as
% on. This annoying feature of the code is a hangover from when I didn't
% quite understand the implications of the D-switch's healthy state being
% when the B>Bminus configuration. It's best to just note and correct the
% complication here rather than try to edit the base code that does the
% simulations.
% this issue means that overall the network will actually be arranged like
% this:
%         101     111
%          6       8
% 001     011     010     110
%  2       4       3       7
%         000     100
%          1       5

X = [0.375;0.127;0.625;0.375;0.625;0.375;0.875;0.625];
Y = [0.2;0.5;0.5;0.5;0.2;0.8;0.5;0.8];
p = inputParser;
p.addOptional('XLoc', X, @(x) isnumeric(x) && isvector(x) && length(x)==8);
p.addOptional('YLoc', Y, @(y) isnumeric(y) && isvector(y) && length(y)==8);
p.addOptional('nodeLabels', cell(1,8), @(x) assert(iscell(x), 'Must be a cell of length 8.'));
p.addOptional('edgeLabels', cell(8,8), @(x) assert(iscell(x), 'Must be a cell of size 8x8.'));
p.addOptional('edgeLabelLocation', cell(8,8), @(x) assert(iscell(x), 'Must be a cell of size 8x8.')); % convenience argument for redefining where the label should appear
p.addParameter('tree', false);
p.addParameter('label_circles', false, @(x) assert(islogical(x), '''label_circles'' must be either true or false'));
p.addParameter('FontSize', 12, @(x) assert(isnumeric(x) && isscalar(x), '''font_size'' defines the size of the labelling text within the circles. It mst be a numeric scalar.'));
p.addParameter('mark_transient_loops', false);
p.addParameter('raw', false);
p.addParameter('to_plot', obj.to_plot);
p.addParameter('plot_arrows', true, @islogical);
p.addParameter('plot_order',1:8, @(x) assert(isnumeric(x) && isvector(x) && length(x)==8, 'Must be a numeric vector of length 8'));
p.addParameter('forced_transition', [], @(x) assert(isnumeric(x) && isvector(x) && length(x)==2, 'Must be a numeric vector of length 2 specifying the [from, to] indices of the nodes.'));
p.addParameter('squirrel_transition', [],  @(x) assert(isnumeric(x) && isvector(x) && length(x)==2, 'Must be a numeric vector of length 2 specifying the [from, to] indices of the nodes we want to squirrel to move along. Note this will not plot the arrow. Use "forced_transition" to get a red arrow plotted.'));
p.addParameter('squirrel_pose', 'jump'); %, @(x) assert(ismember(x, {'jump','scamper','sit'}, 'Options for squirrel poses: jump, scamper or sit')));
p.addParameter('squirrel_jump_height',0.3,  @(x) assert(isnumeric(x) && isscalar(x), '''squirrel_jump_height'' defines how far above the jump arrow the squirrel cartoon is plotted (default value=0.3).'));
p.addParameter('squirrel_scale', 0.2,  @(x) assert(isnumeric(x) && isscalar(x), '''squirrel_scale'' defines how large squirrel cartoon is plotted (default value=0.2).'));
p.addParameter('plot_white_background_layer', false, @islogical);
parse(p, varargin{:});

XLoc = p.Results.XLoc;
YLoc = p.Results.YLoc;
nodeLabels = p.Results.nodeLabels;
edgeLabels = p.Results.edgeLabels;
edgeLabelLocation = p.Results.edgeLabelLocation;
tree = p.Results.tree;
if tree % if we're plotting a tree diagram, we don't need to worry about overlapping lines
    plot_white_background_layer = p.Results.plot_white_background_layer;
else % if we're plotting any other layout than a tree, take measures to deal with overlapping arrows
    plot_white_background_layer = true;
end
label_circles = p.Results.label_circles;
font_size = p.Results.FontSize;
mark_transient_loops = p.Results.mark_transient_loops;
raw  = p.Results.raw;
to_plot = p.Results.to_plot; % This defaults to the obj.to_plot value if not specified at the input.
plot_arrows = p.Results.plot_arrows;
plot_order = p.Results.plot_order;

% inputs for plotting forced transitions
forced_transition    = p.Results.forced_transition;
squirrel_transition  = p.Results.squirrel_transition;
squirrel_pose        = p.Results.squirrel_pose;
squirrel_jump_height = p.Results.squirrel_jump_height;
squirrel_scale       = p.Results.squirrel_scale;
if raw % just plot the network using MATLAB's native graph plotting functionality. This is less neat, but can be helpful for debugging as it shows raw node numbers.
    G = digraph(obj.F);
    plot(G);
    return;
end

% first, set the layout of the network
if tree
    [XLoc, YLoc] = obj.tree_layout('mark_transient_loops', mark_transient_loops);
end

if mark_transient_loops
    obj.F = obj.F + obj.transient_loop_exits;
end

if any(isnan(XLoc))
    error('Switch state location allocation failed');
end

XLoc_spacing = max(diff(sort(XLoc)));
YLoc_spacing = max(diff(sort(YLoc)));

if any(isnan(XLoc))
    disp('debug');
end
% remember, the switch state image consists of three adjacent circles,
% meaning the total image consists of a rectangular area of base "width",
% and height "width/3".
% %%%%%%%%%
% % image %
% %%%%%%%%%
width = 0.6*XLoc_spacing; % width of the switch state images will be 60% the distance from centre to centre of two adjacent switch state images.

ax = gca;
ax.DataAspectRatio = [1 1 1];
ax.Visible = 'off';
ax = obj.label_nodes(ax, XLoc, YLoc, width, nodeLabels);
ax = obj.switch_state_circles(ax, XLoc, YLoc, width, obj.switchStates, to_plot, label_circles, font_size);

%% add the arrows between switch states
% this is the part which actually looks at the network represented by the
% matrix F

arrowhead = polyshape([0, -1, -1, 0], [0, -0.5, 0.5, 0]);
if YLoc_spacing~=0
    sf = 0.05*min(YLoc_spacing,XLoc_spacing)/0.25; % scale factor for arrowheads
else
    sf = 0.05*XLoc_spacing/0.25;
end
squish = 0.2*XLoc_spacing/0.25; % scale factor for squiching the curved arrows for oscillations (tuned by trial and error)
stretch = 1.3*XLoc_spacing/0.25; % scale factor for stretching the curved arrows for oscillations (tuned by trial and error)
sfas = 0.05*XLoc_spacing/0.25; % scale factor for curved arrows for absorbing states

buffer = 0.5; % The buffer zone around the circles image into which the lines will not stray, measured as a fraction of the image width.

if plot_arrows
    for from=plot_order % iterate through each node from 1 to 8
        for to = find(obj.F(from,:))
            % calculate the offset required for each line so that we're not
            % plotting the arrows originating from the centre of each switch state
            % image.
            % first, calculate the gradient of the line
            %     first calculate the vector representing the direciton of the line
            A = [XLoc(from),YLoc(from)];
            B = [XLoc(to),YLoc(to)];

            vec = B - A;
            ang = angle(vec(1)+1j*vec(2)); % angle of the vector (used for plotting the arrow heads and working out how to rotate the curved arrow lines

            Y = YLoc([from,to]);
            X = XLoc([from,to]);
            if from==to % if we're looking at a self-loop
                theta = (pi/4:0.1:7*pi/4)'; % produces an circular arc protruding to the left.
                if from==1 || tree % rotate the arrow by pi/2 if we're at node #1 or we're making a tree network
                    rot_ang = pi/2;
                    trans = A + [0,-(1+buffer)*width/3];
                    ang_offset = 3*pi/8;
                elseif from==2 % we're good with the current theta range
                    rot_ang = 0;
                    trans = A + [-(1+buffer)*width/3,0];
                    ang_offset = 15*pi/8;%angle(2 - 1j);
                elseif from==8 % rotate by -pi/2
                    % rotation
                    rot_ang = - pi/2;
                    % transformation
                    trans = A + [0,(1+buffer)*width/3];
                    % arrow angle offset
                    ang_offset = 11*pi/8;%angle(-1 - 1j*2);
                elseif from==7 % rotate by pi
                    rot_ang = pi;
                    trans = A + [(1+buffer)*width/3,0];
                    ang_offset = 7*pi/8;%angle(-2 + 1j);
                end
                % construct the transformation matrices
                R = [cos(rot_ang), sin(rot_ang); -sin(rot_ang), cos(rot_ang)];
                S = [sfas, 0; 0, sfas]; % identity matrix i.e. no stretch since we're dealing with absorbing states
                % transform the arc segment
                curve = [cos(theta),sin(theta)]*S*R + repmat(trans, length(theta), 1);

                X = curve(:,1);
                Y = curve(:,2);
                B_bar = [X(1), Y(1)];
            elseif obj.F(from,to) && obj.F(to,from) % we've got an oscillation
                theta = (pi/4:0.1:3*pi/4)'; % produces an circular arc from 3*pi/4 to pi/4.

                % work out if the curve needs to be stretched to rach the node
                % distance between arrow start and end is sqrt(2).
                lngth = norm(vec);
                sfc = lngth/(stretch*sqrt(2));

                R = [cos(ang), sin(ang); -sin(ang), cos(ang)];
                S = [sfc, 0; 0, squish/(2*sqrt(2))]; % identity matrix i.e. no stretch since we're dealing with absorbing states

                trans = A + 0.5*vec;

                % transform the arc segment
                curve = [cos(theta),sin(theta)]*S*R + repmat(trans, length(theta), 1);

                X = curve(:,1);
                Y = curve(:,2);

                % modify the vector defining the arrow direction to get the arrow
                % head to bend in the correct direction.
                ang_offset = -pi/8;

                B_bar = [X(1), Y(1)];
            else % if the vector actually points somewhere.
                % calculate trimming of the vector to respect the rectangular area
                % of the switch state image

                if abs(vec(2)/vec(1))<tan(1/3) % 1/3 is the aspect ratio of the image shape
                    % calculate intercept of arrow line with bounding box of switch
                    % states image
                    % propotion of way along arrow where intercept takes place
                    lambda = ((1+buffer/3)*width/2)/abs(vec(1));
                else
                    lambda = ((1+buffer)*width/6)/abs(vec(2));
                end
                A_bar = A + lambda*vec;
                B_bar = B - lambda*vec;

                X = [A_bar(1), B_bar(1)];
                Y = [A_bar(2), B_bar(2)];

                ang_offset = 0;
            end
            if plot_white_background_layer
                % plot a white line in the background, which is thicker than the
                % black line so we effectively get a border for any lines that end
                % up crossing.
                whiteln = plot(ax, X, Y);
                whiteln.LineWidth = 5;
                whiteln.Color = 'white';
            end
            %% add arrow head
            % scale the arrowhead to about the right size
            this_head = scale(arrowhead, sf);
            this_head = rotate(this_head, (ang+ang_offset)*180/pi); % this function likes the angle in degrees rather than radians
            % translate the arrowhead to the end of the line
            this_head = translate(this_head, B_bar);

            if plot_white_background_layer
                % plot the arrow head with a thick white border for buffering any
                % overlaps
                whiteh = plot(ax, this_head);
                whiteh.FaceColor = 'white';
                whiteh.EdgeColor = 'white';
                whiteh.LineWidth = 3;
            end
            h = plot(ax, this_head);
            if mark_transient_loops
                if obj.transient_loop_exits(from,to)
                    h.FaceColor = 'b';
                else
                    h.FaceColor = 'k';
                end
            else
                h.FaceColor = 'k';
            end
            h.FaceAlpha = 1;

            %% finally, add the  black (or blue) arrow line
            ln = plot(ax, X, Y);
            if mark_transient_loops
                if obj.transient_loop_exits(from,to)
                    ln.Color = 'b';
                else
                    ln.Color = 'k';
                end
            else
                ln.Color = 'k';
            end
            ln.LineWidth = 1;

            %% add edge labels (if asked for them)
            % label the node with the characters in the cell array
            if ~isempty(edgeLabels{from,to})
                if isempty(edgeLabelLocation{from, to}) % if label location is undefined, we calculate where it should be
                    % vector specifying the direction of the arrow is vec
                    % orthvec is the same vector, rotated by pi/2 radians.
                    orthvec = [-vec(2), vec(1)]/norm(vec); % normalise by the length of vec for consistent scaling
                    label_loc = [X(1),Y(1)] + 0.2*vec + 0.03*orthvec;
                    text(label_loc(1), label_loc(2), edgeLabels{from,to},'HorizontalAlignment','center','VerticalAlignment','middle');
                else
                    if ischar(edgeLabelLocation{from, to})
                        if ismember(edgeLabelLocation{from, to},'flip')
                            % vector specifying the direction of the arrow is vec
                            % orthvec is the same vector, rotated by -pi/2
                            % radians. (note it's flipped relative to the
                            % normal configuration
                            orthvec = -[-vec(2), vec(1)]/norm(vec); % normalise by the length of vec for consistent scaling
                            label_loc = [X(1),Y(1)] + 0.2*vec + 0.03*orthvec;
                            text(label_loc(1), label_loc(2), edgeLabels{from,to},'HorizontalAlignment','center','VerticalAlignment','middle');
                        else
                            error('You can specify the edgeLabelLocation as ''flip'' or specify the location (x- and y-limits are normalised to 0 and 1');
                        end
                    else
                        text(edgeLabelLocation{from, to}(1), edgeLabelLocation{from, to}(2), edgeLabels{from,to},'HorizontalAlignment','center','VerticalAlignment','middle');
                    end
                end
            end
        end
    end
end
if ~ isempty(forced_transition) % if we're being asked to plot a forced transition arrow. We use red to mark this.
    from = forced_transition(1);
    to = forced_transition(2);
    % calculate the offset required for each line so that we're not
    % plotting the arrows originating from the centre of each switch state
    % image.
    % first, calculate the gradient of the line
    %     first calculate the vector representing the direciton of the line
    A = [XLoc(from),YLoc(from)];
    B = [XLoc(to),YLoc(to)];

    vec = B - A;
    ang = angle(vec(1)+1j*vec(2)); % angle of the vector (used for plotting the arrow heads and working out how to rotate the curved arrow lines

    Y = YLoc([from,to]);
    X = XLoc([from,to]);
    % calculate trimming of the vector to respect the rectangular area
    % of the switch state image

    if abs(vec(2)/vec(1))<tan(1/3) % 1/3 is the aspect ratio of the image shape
        % calculate intercept of arrow line with bounding box of switch
        % states image
        % propotion of way along arrow where intercept takes place
        lambda = ((1+buffer/3)*width/2)/abs(vec(1));
    else
        lambda = ((1+buffer)*width/6)/abs(vec(2));
    end
    A_bar = A + lambda*vec;
    B_bar = B - lambda*vec;

    X = [A_bar(1), B_bar(1)];
    Y = [A_bar(2), B_bar(2)];

    ang_offset = 0;
    if plot_white_background_layer
        % plot a white line in the background, which is thicker than the
        % black line so we effectively get a border for any lines that end
        % up crossing.
        whiteln = plot(ax, X, Y);
        whiteln.LineWidth = 5;
        whiteln.Color = 'white';
    end
    %% add arrow head
    % scale the arrowhead to about the right size
    this_head = scale(arrowhead, sf);
    this_head = rotate(this_head, (ang+ang_offset)*180/pi); % this function likes the angle in degrees rather than radians
    % translate the arrowhead to the end of the line
    this_head = translate(this_head, B_bar);

    if plot_white_background_layer
        % plot the arrow head with a thick white border for buffering any
        % overlaps
        whiteh = plot(ax, this_head);
        whiteh.FaceColor = 'white';
        whiteh.EdgeColor = 'white';
        whiteh.LineWidth = 3;
    end
    h = plot(ax, this_head);
    h.FaceColor = 'red';
    h.EdgeColor = 'red';
    h.FaceAlpha = 1;

    %% finally, add the  black (or blue) arrow line
    ln = plot(ax, X, Y);
    ln.Color = 'red';
    ln.LineWidth = 1;
end
if ~isempty(squirrel_transition)
    % import the squirrel pngs
    if strcmp(squirrel_pose, 'jump')
        [squirrel, ~, transparancy] = imread('+NetworkAnalysis/@Network/jumping_squirrel.png');
    elseif strcmp(squirrel_pose, 'scamper')
        [squirrel, ~, transparancy] = imread('+NetworkAnalysis/@Network/scampering_squirrel.png');
    elseif strcmp(squirrel_pose, 'sit')
        [squirrel, ~, transparancy] = imread('+NetworkAnalysis/@Network/sitting_squirrel.png');
    end

    % work out the angle of the squirrel's jump
    from = squirrel_transition(1);
    to = squirrel_transition(2);
    % calculate the offset required for each line so that we're not
    % plotting the arrows originating from the centre of each switch state
    % image.
    % first, calculate the gradient of the line
    %     first calculate the vector representing the direciton of the line
    A = [XLoc(from),YLoc(from)];
    B = [XLoc(to),YLoc(to)];

    vec = B - A;
    ang = angle(vec(1)+1j*vec(2)); % angle of the vector (used for plotting the arrow heads and working out how to rotate the curved arrow lines

    if vec(1)<0
        % mirror-image the squirrel cartoon so it jumps to the left instead of
        % the right
        squirrel = flip(squirrel,2);
        transparancy = flip(transparancy,2);

        ang_offset = 180;
    else
        ang_offset = 0;
    end
    
    % calculate the vector orthogonal to "vec" (the transition our squirrel
    % is jumping). This will help us offset the squirrel from the arrow.
    if vec(1)>=0 % if the jump is going upwards or horizontal
        R = [0, 1;
            -1,0]; % rotate by 90'
    else
        R = [0, -1;
            1,0]; % rotate by -90'
    end
    orth_vec = vec*R;

    % rotate the image to the appropriate angle to make it look like the
    % squirrel is jumping or scampering from one state to the next.
    squirrel = imrotate(squirrel,-ang*180/pi+ang_offset); % imrotate rotates things clockwise by default, rather than anticlockwise which is the default mathematical definition (hence the -ve sign).
    transparancy= imrotate(transparancy,-ang*180/pi+ang_offset);
    % % scale down the image to make it fit on the diagram nicely
    % squirrel = imresize(squirrel,0.5);
    % transparancy= imresize(transparancy, 0.5);

    % find the location vector S_bar for placing the squirrel
    S_bar = (A + B)/2 + squirrel_jump_height*orth_vec;

    % add the squirrel, giving it a 0.2 by 0.2 box for plotting area,
    % centred on the desired transition arrow.
    im = image(ax, S_bar(1)+[-squirrel_scale,squirrel_scale]/2,S_bar(2)+[-squirrel_scale,squirrel_scale]/2,...
        squirrel, 'AlphaData', transparancy);
end
fig = ax.Parent;
end