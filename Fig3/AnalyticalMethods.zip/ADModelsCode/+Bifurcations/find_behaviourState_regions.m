function [behaviourStateList, RK_reD_list, D_reg] = find_behaviourState_regions(model,kappa_M_range,alpha_M_range,kappa_B_range,delta_B_range,varargin)
%FIND_BEHAVIOURSTATE_REGIONS Construct behaviour–state tables over parameter space.
%
% Steps:
% 1. Compute D-switch behaviour regions in (kappa_B, delta_B).
% 2. For each D-region (using its centroid parameters), compute RK-switch
%    behaviour regions in (kappa_M, alpha_M).
% 3. Combine each RK-region with its D-region to form a BehaviourStateTable,
%    summarising the 8 switch configurations in that parameter region.

%% Parse inputs
p = inputParser;

% positional parameters defining the range of the axes on the bifurcation
% diagrams
p.addRequired('model', @(x) isa(x, 'ADModels.SkinModelv2'));
p.addRequired('kappa_M_range', @(x) isnumeric(x) && isvector(x));
p.addRequired('alpha_M_range', @(x) isnumeric(x) && isvector(x));
p.addRequired('kappa_B_range', @(x) isnumeric(x) && isvector(x));
p.addRequired('delta_B_range', @(x) isnumeric(x) && isvector(x));
p.addParameter('check', true, @islogical);

p.parse(model, kappa_M_range, alpha_M_range, kappa_B_range, delta_B_range,varargin{:});

model   = p.Results.model;
kappa_M_range = p.Results.kappa_M_range;
alpha_M_range = p.Results.alpha_M_range;
kappa_B_range = p.Results.kappa_B_range;
delta_B_range = p.Results.delta_B_range;
check = p.Results.check;

% import Bifurcations.BoundaryEquilibrium;
% import ADModels.SkinModelv2;
this_model = model; % this model contains all of the parameter values we're interested in within this object.

% D-switch bifurcation regions
D_reg  = this_model.regions_D_switch(kappa_B_range, delta_B_range, 'check', check); % arguments: kappa_B_lim, delta_B_lim
% these D-switch behaviour regions each has a unique set of kappa_B,
% delta_B parameter values

RK_reD_list = [];
behaviourStateList = [];

% For each D-region, compute RK-regions and assemble behaviour-state tables
for this_D_reg = D_reg.overlap' 
    % Model parameters are set to the centroid of the D-region
    this_model = this_D_reg.model;
    
    RK_reg = this_model.regions_RK_switch(kappa_M_range, alpha_M_range,'check', check); % arguments: kappa_M_lim, alpha_M_lim
    RK_reD_list = vertcat(RK_reD_list,RK_reg);
    
    % the RK_reg should be a struct containing the bifurcation diagram
    % regions, and the overlaps from D-switch=off and D-switch=on
    n_RK_overlap_regions = length(RK_reg.overlap);
    for i=1:n_RK_overlap_regions
        % merge the two behaviour regions together into one behaviour state
        % table.
        bs = Bifurcations.BehaviourStateTable(RK_reg.overlap(i), this_D_reg);
        
        behaviourStateList = [behaviourStateList;bs];
    end
end
end