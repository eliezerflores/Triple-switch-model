function m = set_parameters(m, parameters)

% Determine how many parameter sets are provided.Each element of `parameters` represents 
% one complete parameter set, so we just calculate the length.
n_param_sets = length(parameters);

% Check that the number of model objects equals the number of parameter sets.
% Each model object should receive exactly one parameter set.
if length(m)~=n_param_sets
    error('we need the same number of model objects as parameter values');
end

for i=1:n_param_sets
m(i).parameters = parameters(i).ODE; % Assign ODE parameters to the model
m(i) = m(i).set_switchParameters(parameters(i).switchParameters); % Assign switch parameters to the model
end
end