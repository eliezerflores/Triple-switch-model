function summaryTable = summary(obj)
% SUMMARY Return a compact switch-state + behaviour table for one or more BehaviourRegion objects.

n_switchStates_per_region = height(obj(1).switchStates);

% Stack the switch-state tables from all regions into one big table.
switchStatesAll = vertcat(obj.switchStates);

% Drop switch columns that are entirely NaN
% Interpretation: if a switch column is all NaN across the stacked table,
% that switch is not "active / specified" for these regions, so we remove
% it to keep the summary concise and downstream joins simpler.
for column_name = switchStatesAll.Properties.VariableNames
    if all(isnan(switchStatesAll.(string(column_name))))
        switchStatesAll = removevars(switchStatesAll,string(column_name));
    end
end

n_regions = length(obj);

% If we summarise multiple regions, prepend a Region_number column so each
% row can be traced back to its region in obj.
if n_regions>1
    reg_number = table(repelem((1:n_regions)',n_switchStates_per_region,1),'VariableNames', {'Region_number'});
    summaryTable = [reg_number,switchStatesAll,vertcat(obj.behaviour)];
else
    summaryTable = [switchStatesAll, obj.behaviour];
end

% Add suffix "_state" to columns that came from switchStates, so it's
% explicit these are switch configurations (not behaviours).
switchStatesColumns = ismember(summaryTable.Properties.VariableNames, obj(1).switchStates.Properties.VariableNames);
summaryTable.Properties.VariableNames(switchStatesColumns) = append(summaryTable.Properties.VariableNames(switchStatesColumns),'_state');

% Add suffix "_behaviour" to behaviour columns for the same reason.
behaviourColumns = ismember(summaryTable.Properties.VariableNames, obj(1).behaviour.Properties.VariableNames);
summaryTable.Properties.VariableNames(behaviourColumns) = append(summaryTable.Properties.VariableNames(behaviourColumns),'_behaviour');
end