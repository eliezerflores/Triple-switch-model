classdef SkinModelv2 < ADModels.ADModelsInterface
%SKINMODELV2 Triple-switch atopic dermatitis (AD) hybrid model.

    properties ( Constant = true, Access = public ) 
        % Names for parameters, states and switches
        % these properties will be publicly visible but unchangeable
        parameterNames = {'B_ex','M_ex', 'M_env','kappa_M','alpha_M','gamma_MB','delta_M','kappa_B','gamma_BB','gamma_BR','delta_B','kappa_A','gamma_AB','delta_A','kappa_C','delta_C'}
        stateNames = {'M', 'B', 'A', 'C'}
        switchNames = {'RK_switch', 'T_switch', 'D_switch'}
        
        % LaTeX strings for documentation only (not used by computations)
        equations = {'% Please add the following required packages to your document preamble:';
                     '% \usepackage{amsmath}'; 
                     '\begin{aligned}';
                     '    \frac{dM(t)}{dt} &=& \(M_{env}+M_{ex})\frac{\kappa_M}{1+\gamma_MB B(t)} - \alpha_M A(t)M(t) - \delta_M M(t)\\';
                     '    \frac{dB(t)}{dt} &=& \kappa_B \frac{1}{1+\gamma_BB B(t)}\frac{1}{1+\gamma_BR R(t)}D(t) - \delta_B K(t)B(t) - \B_exB(t)\\'; % used to be \frac{dB(t)}{dt} &=& \kappa_B \frac{1}{1+\gamma_RR(t)}\frac{1}{1+\gamma_GG(t)}(1-B(t)) - \delta_BK(t)B(t) - \B_exB(t)\\';
                     '    \frac{dC(t)}{dt} &=& \kappa_C R(t) - \delta_C C(t)';
                     '    \frac{dA(t)}{dt} &=& \kappa_A \frac{1}{1+\gamma_AB B(t)} D(t) - \delta_A A(t)';
                     '\end{aligned}';
                     '';
                     '% D switch';
                     '\begin{equation}';
                     '    D(t)=\begin{cases} D_{\text{off}} \rightarrow D_{\text{on}} & \text{if } \dot{B}(t) > 0 \text{ and } B(t) = B^{+} \\ D_{\text{on}} \rightarrow D_{\text{off}}, & \text{if } \dot{B}(t) < 0 \text{ and } B(t) = B^{-} \end{cases}';
                     '\end{equation}';
                     '';
                     '% R (K) switch';
                     '\begin{equation}';
                     '    (R(t), K(t))=\left\{\begin{array}{ll}{\left(R_{\text { off }}, K_{\text { off }}\right) \rightarrow\left(R_{\text { on }}, K_{\text { on }}\right)} & {\text { if } \dot{M}(t)>0 \text { and } M(t)=M^{+}} \\ {\left(R_{\text { on }}, K_{\text { on }}\right) \rightarrow\left(R_{\text { off }}, K_{\text { off }}\right)} & {\text { if } \dot{M}(t)<0 \text { and } M(t)= M^{-}}\end{array}\right.';
                     '\end{equation}'};
    end
    
    properties ( Access = public ) 
        % Switch thresholds (per switch configuration) and discrete switch
        % mappings.
        % These tables define how each switch state maps to model
        % functions/values.
        name {isstring} = [];
        switchValues {istable} = table([0.2, 0.8; 0.2, 0.8; 0.2, 0.8; 0.2, 0.8], [0.2, 0.8;0.3, 0.9;0.1, 0.7;0.2, 0.8], [0.2, 0.8; 0.2, 0.8; 0.2, 0.8; 0.2, 0.8],...
            'VariableNames', {'RK_switch', 'D_switch', 'T_switch'},...
            'RowNames', {'00','10','01','11'})
        RFunction {istable} = table ( 0, 1, 'VariableNames', {'off', 'on'} )
        KFunction {istable} = table ( 1, 2, 'VariableNames', {'off', 'on'} )
        DFunction {istable} = table ( 2, 1, 'VariableNames', {'off', 'on'} ) % D_off = unhealthy setting, D_on = healthy.
        TFunction {istable} = table ( 0, 1, 'VariableNames', {'off', 'on'} )
    end
    
    properties ( Access = private )
        % Convenience lookup: which state variable each switch acts on.
        stateFor {istable} = table ( "M", "B", "C", 'VariableNames', {'RK_switch', 'D_switch', 'T_switch'} ) % reference table for convenience
    end
    
    properties (Dependent = true)
        % Steady states under the current parameter + switch configuration.
        steadyStates
    end
    
    methods ( Access = public )
        % constructor: initialise parameters, switch states/values, and
        % switch mappings.
        function m = SkinModelv2 (varargin)
            p = inputParser;
            addParameter ( p, 'switchStates', [] );
            addParameter ( p, 'switchValues', [] );
            addParameter ( p, 'parameters', [] );
            addParameter ( p, 'RFunction', [] );
            addParameter ( p, 'KFunction', [] );
            addParameter ( p, 'DFunction', [] );
            addParameter ( p, 'TFunction', [] );
            
            parse ( p, varargin{:} );
            
            if ~isempty( p.Results.parameters )
                m.parameters   = p.Results.parameters;
            else % default values
                m.parameters = table ( 1, 1,    1 ,       1 ,       1 ,        1 ,        1 ,       1 ,       1 ,       1  ,       1 ,       1 ,        1 ,       1 ,       1 ,       1 ,...
                    'VariableNames', {'B_ex','M_ex','M_env','kappa_M','alpha_M','gamma_MB','delta_M','kappa_B','gamma_BB','gamma_BR','delta_B','kappa_A','gamma_AB','delta_A','kappa_C','delta_C'} );
            end
            if ~isempty( p.Results.switchStates )
                m.switchStates = p.Results.switchStates;
            else
                m.switchStates = table ( false, false, 0, 'VariableNames', {'RK_switch', 'D_switch', 'T_switch'}); % we're setting the T-switch value to be an integar since it can take up 3 different values [0, 1, 2]
            end
            if ~isempty( p.Results.switchValues )
                m.switchValues = p.Results.switchValues;
            end
            if ~isempty( p.Results.RFunction )
                m.RFunction    = p.Results.RFunction;
            end
            if ~isempty( p.Results.KFunction )
                m.KFunction    = p.Results.KFunction;
            end
            if ~isempty( p.Results.DFunction )
                m.KFunction    = p.Results.DFunction;
            end
            if ~isempty( p.Results.TFunction )
                m.KFunction    = p.Results.TFunction;
            end
        end
        
        switch_behaviours = bifurcation_diagram_behaviours(m)

        % --- simulation method for the positive feedback m ---
        [times, states, tSw, ySw, switchBehaviours] = simulate ( m, times, varargin )
        [times, states, tSw, ySw] = simulate_RK_forcing ( m, times, varargin )

        % --- Analytic region construction ---
        % Calculate polygonal behaviour regions in the bifurcation diagrams
        outputstruct = regions_D_switch(m, kappa_B_Lim, delta_B_Lim,varargin)
        outputstruct = regions_RK_switch(obj,kappa_M_Lim, alpha_M_Lim,varargin)
        
        % --- bifurcation diagrams ---
        [shapes_off, shapes_on, shapes_overlap] = D_switch_bif_diagram_shapes ( m, kappa_B_Lim, delta_B_Lim )
        [shapes_off, shapes_on, shapes_overlap] = RK_switch_bif_diagram_shapes ( m, kappa_M_Lim, alpha_M_Lim )
        
        % --- Qualitative classification of RK-plane region ---
        behaviour = qualitativeBehaviourBinary ( m, kappa_M, alpha_M, Mminus, Mplus )
        %%??? B
        % --- Convenience setting function ---
        % Set all switch thresholds + switch functions in one struct/table
        function m = set_switchParameters(m, switchParameters)
            m.RFunction = switchParameters.RFunction;
            m.KFunction = switchParameters.KFunction;
            m.TFunction = switchParameters.TFunction;
            m.DFunction = switchParameters.DFunction;   

            m.switchValues.RK_switch = switchParameters.RK_switch;
            m.switchValues.T_switch  = switchParameters.T_switch;
            m.switchValues.D_switch  = switchParameters.D_switch;
        end
        
        % Plot helper for a chosen parameter-set index i
        [RK_fig, D_fig] = draw_bifurcation_diagrams(m, transitions, i)
    end
    
    methods
        ax = plot_switch(obj, ax, switch_spec, varargin) % Plot a selected switch over an axis (utility for figure scripts)
        
        [F, num] = calculate_transition_matrix(m, parameters, RK_switch_region, D_switch_region)
        
        parameters = get_parameters_table ( m )
        m = set_parameters_table ( m, parameters )
        
        % --- steady state calculations ---
        function steadyStates = get.steadyStates ( m )
            switchStates = m.switchStates;
            steadyStates = get_steadyStates ( m, switchStates );
        end
        
        % --- Set switch thresholds ---
        function m = set.switchValues ( m, switchValues )
            if isstruct ( switchValues )
                switchValues = struct2table ( switchValues );
            end
            if istable ( switchValues )
                switchNames = m.switchValues.Properties.VariableNames;
                present = ismember ( switchNames, switchValues.Properties.VariableNames );
                if ( sum(present) ~= length(switchNames) ) % if not all parameters are accounted for
                    error(['Switch(es) [', strjoin(switchNames(~present),', '), '] did not appear in the switch values table you provided. Please provide these.']);
                end
                m.switchValues = switchValues;
            elseif ismatrix ( switchValues )
                if any ( size ( switchValues ) ~= [1, 2] )
                    error ( 'Switch values matrix must be a 1*2 matrix. Alternalively, provide a table.' );
                end
                m.switchValues.RK_switch = switchValues(1);
                m.switchValues.T_switch  = switchValues(2);
            else
                error('Please provide the switch values as a table');
            end
        end
        
        function m = set.RFunction ( m, values )
            if isstruct ( values )
                values = struct2table ( values );
            end
            if istable ( values )
                states = m.RFunction.Properties.VariableNames;
                present = ismember ( states, values.Properties.VariableNames );
                if ( sum(present) ~= length(states) ) % if not all parameters are accounted for
                    error(['States(es) [', strjoin(states(~present),', '), '] did not appear in the R-function table you provided. Please provide these.']);
                end
                m.RFunction.off = values.off;
                m.RFunction.on  = values.on;
            elseif ismatrix ( values )
                if any ( size ( values ) ~= [1, 2] )
                    error ( 'Switch values matrix must be a 1*2 matrix. Alternalively, provide a table.' );
                end
                m.RFunction.off = values(1);
                m.RFunction.on  = values(2);
            end
        end
        
        function m = set.KFunction ( m, values )
            if isstruct ( values )
                values = struct2table ( values );
            end
            if istable ( values )
                states = m.KFunction.Properties.VariableNames;
                present = ismember ( states, values.Properties.VariableNames );
                if ( sum(present) ~= length(states) ) % if not all parameters are accounted for
                    error(['States(es) [', strjoin(states(~present),', '), '] did not appear in the K-function table you provided. Please provide these.']);
                end
                m.KFunction.off = values.off;
                m.KFunction.on  = values.on;
            elseif ismatrix ( values )
                if any ( size ( values ) ~= [1, 2] )
                    error ( 'Switch values matrix must be a 1*2 matrix. Alternalively, provide a table.' );
                end
                m.KFunction.off = values(1);
                m.KFunction.on  = values(2);
            end
        end
        
        function m = set.TFunction ( m, values )
            if isstruct ( values )
                values = struct2table ( values );
            end
            if istable ( values )
                states = m.TFunction.Properties.VariableNames;
                present = ismember ( states, values.Properties.VariableNames );
                if ( sum(present) ~= length(states) ) % if not all parameters are accounted for
                    error(['States(es) [', strjoin(states(~present),', '), '] did not appear in the T-function table you provided. Please provide these.']);
                end
                m.TFunction.off = values.off;
                m.TFunction.on  = values.on;
            elseif ismatrix ( values )
                if any ( size ( values ) ~= [1, 2] )
                    error ( 'Switch values matrix must be a 1*3 matrix. Alternalively, provide a table.' );
                end
                m.TFunction.off = values(1);
                m.TFunction.on  = values(2);
            end
        end
        
        function m = set.DFunction ( m, values )
            if isstruct ( values )
                values = struct2table ( values );
            end
            if istable ( values )
                states = m.DFunction.Properties.VariableNames;
                present = ismember ( states, values.Properties.VariableNames );
                if ( sum(present) ~= length(states) ) % if not all parameters are accounted for
                    error(['States(es) [', strjoin(states(~present),', '), '] did not appear in the D-function table you provided. Please provide these.']);
                end
                m.DFunction.off = values.off;
                m.DFunction.on  = values.on;
            elseif ismatrix ( values )
                if any ( size ( values ) ~= [1, 2] )
                    error ( 'Switch values matrix must be a 1*2 matrix. Alternalively, provide a table.' );
                end
                m.DFunction.off = values(1);
                m.DFunction.on  = values(2);
            end
        end
        
        % --- Check the two switch bifurcation diagrams conditions ---
        function [RK_satisfied, D_satisfied] = bifDiagramConditions(m)
            n_models = length(m(:));

            % prepare vectors to store the relevant values for a vector of
            % models
            Mminus = zeros(size(m));
            Mplus  = zeros(size(m));
            gamma_MB = zeros(size(m));
            B_bar_RK_off = zeros(size(m));
            A_bar_RK_off = zeros(size(m));
            B_bar_RK_on  = zeros(size(m));
            A_bar_RK_on  = zeros(size(m));
            
            D_off = zeros(size(m));
            D_on  = zeros(size(m));
            gamma_BB = zeros(size(m));
            Bminus_RK0_T0 = zeros(size(m));
            Bplus_RK0_T0 = zeros(size(m));
            
            for i=1:n_models
                Mminus(i) = m(i).switchValues.RK_switch(1,1);
                Mplus(i)  = m(i).switchValues.RK_switch(1,2);
                gamma_MB(i) = m(i).parameters.gamma_MB;
                
                % Evaluate steady states with T=off, D=off at RK=off vs RK=on
                m(i).switchStates.T_switch = false;
                m(i).switchStates.D_switch = false;
                
                % turn off the RK-switch
                m(i).switchStates.RK_switch = false;
                steadyStates_RK_off = m(i).steadyStates;
                B_bar_RK_off(i) = steadyStates_RK_off.B;
                A_bar_RK_off(i) = steadyStates_RK_off.A;

                % turn on the RK-switch
                m(i).switchStates.RK_switch = true;
                steadyStates_RK_on = m(i).steadyStates;
                B_bar_RK_on(i)  = steadyStates_RK_on.B;
                A_bar_RK_on(i)  = steadyStates_RK_on.A;
                
                % Read D thresholds and parameters (currently checked for
                % RK = 0, T = 0)
                D_on(i)  = m(i).DFunction.on;
                D_off(i) = m(i).DFunction.off;
                gamma_BB(i) = m(i).parameters.gamma_BB;
                
                Bminus_RK0_T0(i) = m(i).switchValues.D_switch(1,1);
                Bplus_RK0_T0(i)  = m(i).switchValues.D_switch(1,2);
            end
            
            % RK-switch condition
            RK_satisfied = Mminus.*(1+gamma_MB.*B_bar_RK_on).*A_bar_RK_on -...
                Mplus.*(1+gamma_MB.*B_bar_RK_off).*A_bar_RK_off > 0;
            
            % D-switch condition (for which the thresholds rely on the
            % other switch states).
            D_satisfied = D_on./((2*Bminus_RK0_T0.*gamma_BB + 1).^2 - 1) -...
                D_off./((2*Bplus_RK0_T0.*gamma_BB + 1).^2 - 1) > 0;
        end
    end
    
    methods ( Access = private )

        %% Boundary equilibrium bifurcation lines
        function Bbar = Bbar(obj,R,K,T,D)
            % calculate the steady state value of B for the given R, K, T
            % and D switch values
            gamma_BB = obj.parameters.gamma_BB;
            gamma_BR = obj.parameters.gamma_BR;
            kappa_B  = obj.parameters.kappa_B;
            delta_B  = obj.parameters.delta_B;
            
            B_ex = 0;

            % Solve quadratic for Bbar; take the positive root
            a = gamma_BB;
            b = 1;
            c = -kappa_B*D/((delta_B*K + B_ex)*(1 + gamma_BR*R));
            Bbar = (-b+sqrt(b^2-4*a*c))/(2*a);
        end
        
        function Abar = Abar(obj,R,K,T,D,Bbar)
            % calculate the steady state value of A for the given R, K, T
            % and D switch values
            kappa_A = obj.parameters.kappa_A;
            gamma_AB = obj.parameters.gamma_AB;
            delta_A  = obj.parameters.delta_A;
            
            % calculate Abar
            Abar = kappa_A*D/((1 + gamma_AB*Bbar)*delta_A);
        end
        
        function [m, c] = BE_line_RK_plane(m,R,K,T,D,Mthreshold)
            % calculate the gradient and intercept of the BE bifurcation
            % lines in the (kappa_M, alpha_M) plane for the given R, K, T
            % and D switch values and Mthreshold value
            Bbar = m.Bbar(R,K,T,D);
            Abar = m.Abar(R,K,T,D,Bbar);
            
            M_env = m.parameters.M_env;
            delta_M = m.parameters.delta_M;
            M_ex = 0;
            gamma_MB = m.parameters.gamma_MB;
            
            m = (M_env + M_ex)./( Abar .*Mthreshold.*(1+gamma_MB.* Bbar));
            c = -delta_M/Abar;
            % BE bifurcation line is: alpha_M = m*kappa_M + c
        end
        
        function [m, c] = BE_line_D_plane(m,R,K,T,D,Bthreshold)
            % calculate the gradient and intercept of the BE bifurcation
            % lines in the (kappa_B, delta_B) plane for the given R, K, T
            % and D switch values and Bthreshold value
            
            gamma_BB = m.parameters.gamma_BB;
            gamma_BR = m.parameters.gamma_BR;
            B_ex = 0;
      
            m = 4*gamma_BB*D/(((2*Bthreshold*gamma_BB+1)^2-1)*(1+gamma_BR*R)*K);
            c = -B_ex/K;
            % BE bifurcation line is: delta_B = m*kappa_B + c
        end
    end
end
