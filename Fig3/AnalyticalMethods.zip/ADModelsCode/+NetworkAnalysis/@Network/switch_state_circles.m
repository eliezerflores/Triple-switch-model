function [ax, txt] = switch_state_circles(obj, ax, XLoc, YLoc, width, switchState, to_plot, label_circles, font_size)
%SWITCH_STATE_CIRCLES Plots the three circles plot to express the switch
%state of the model.

% to_plot must be a vector specifying the index of each switch state
% configuration we're plotting here. If all are being plotted, simply
% specify the vector as to_plot = ones(1,8); The number of ones in this
% vector should match the number of x- and y-locations specified inxLoc and
% yLoc.

% convert to_plot to be a row vector for the rest of the processing
if height(to_plot)==length(to_plot)
    to_plot = to_plot';
end

% convert the xLoc and yLoc to column vectors for the rest of the
% processing
if height(XLoc)<length(XLoc)
    XLoc = XLoc';
end
if height(YLoc)<length(YLoc)
    YLoc = YLoc';
end

ax.NextPlot = 'add';

% work out the radius of the circles to meet the requested width when all
% three are placed next to each other
xradius = width/6;
yradius = xradius;

% calculate the location of the centre of the three circles
xLocs = [XLoc-2*xradius, XLoc, XLoc + 2*xradius];
yLocs = repmat(YLoc, 1, 3); % just repeat the y location 3 times in a row

name = obj.switchStates.Properties.VariableNames;

node_index = 1;

for node=find(to_plot)
    circle_polys = obj.circle(xLocs(node,:), yLocs(node,:), xradius, yradius);
    
    pg = plot(ax, circle_polys);
    
    if label_circles
        % add text labels to define each circle
        RK_label = text(xLocs(node,1), yLocs(node,1), 'RK','HorizontalAlignment','center','VerticalAlignment','middle');
        T_label  = text(xLocs(node,2), yLocs(node,2), 'T', 'HorizontalAlignment','center','VerticalAlignment','middle');
        G_label  = text(xLocs(node,3), yLocs(node,3), 'G', 'HorizontalAlignment','center','VerticalAlignment','middle');
    end
    
    for i=1:3
        if label_circles
            if switchState.RK_switch(node)
                RK_label.Color = 'w';
            end
            if switchState.T_switch(node)
                T_label.Color = 'w';
            end
            if ~switchState.G_switch(node) % switching the G-switch polarity because the MATLAB code has the whole thing flipped up the wrong way
                G_label.Color = 'w';
            end
            RK_label.FontSize = font_size;
            T_label.FontSize = font_size;
            G_label.FontSize = font_size;
        end
        if ismember(name{i}, 'G_switch')
            if switchState.G_switch(node)
                % The G-switch labelling works the opposite way to the other
                % switches because of the weird hangover from previous code. I
                % had previousely misunderstood that the G-switch is "healthy"
                % when in the "on" configuration. Thus, rather than edit the
                % base code, we simply draw the G-switch as a white circle when
                % on, and as a red circle when off.
                pg(i).FaceColor = 'w';
            else
                pg(i).FaceColor = 'r';
            end
        else
            if switchState.(name{i})(node)
                % the switch is on, mark the circle in red
                pg(i).FaceColor = 'r';
            else
                pg(i).FaceColor = 'w';
            end
        end
        pg(i).FaceAlpha = 1;
        pg(i).EdgeColor = 'k';
        pg(i).LineWidth = 0.8;
    end
end
end