function circ = circle(obj, x, y, radius_x, radius_y)
%CIRCLE make a circular polyshape for plotting
theta = (0:0.2:(2*pi-0.2))';
x_loop = radius_x*sin(theta)+x;
y_loop = radius_y*cos(theta)+y;

for i=1:width(x_loop)
    circ(i) = polyshape(x_loop(:,i), y_loop(:,1));
end
end