function steadyStates = get_steadyStates ( m, switchStates )

% switchStates must be a table of switch states with VariableNames
% {'RK_switch', 'D_switch'}. Note the T-switch state does not attect the
% steady state values, so it's not necessary to include it here.

B_ex      = m.parameters.B_ex;
M_ex      = m.parameters.M_ex;
M_env    = m.parameters.M_env;
kappa_M  = m.parameters.kappa_M;
alpha_M  = m.parameters.alpha_M;
gamma_MB = m.parameters.gamma_MB;
delta_M  = m.parameters.delta_M;
kappa_B  = m.parameters.kappa_B;
gamma_BB = m.parameters.gamma_BB;
gamma_BR = m.parameters.gamma_BR;
gamma_AB = m.parameters.gamma_AB;
delta_B  = m.parameters.delta_B;
kappa_A  = m.parameters.kappa_A;
delta_A  = m.parameters.delta_A;
kappa_C  = m.parameters.kappa_C;
delta_C  = m.parameters.delta_C;

if switchStates.RK_switch % if RK switch is on
    R = m.RFunction.on; % set the R value to R_on
    K = m.KFunction.on; % set the K value to K_on
else
    R = m.RFunction.off; 
    K = m.KFunction.off;
end

if switchStates.D_switch
    D = m.DFunction.on;
else
    D = m.DFunction.off;
end

M_ex = 0;
B_ex = 0;
C_ex = 0;

Css = (kappa_C*R+C_ex)./delta_C;

% coefficients for the quadratic Bss solution
a = gamma_BB;
b = 1;
c = -kappa_B*D/((1 + gamma_BR*R)*(delta_B*K + B_ex));

Bss = (-b+sqrt(b^2-4*a*c))/(2*a); % we only keep this positive root.

% Ass and Mss are just scaled versions of Bss
Ass = kappa_A.*D./(delta_A.*(1 + gamma_AB.*Bss));
Mss = (M_env + M_ex).*kappa_M./((alpha_M.*Ass + delta_M).*(1 + gamma_MB.*Bss));

% Arrange the output structure
steadyStates = table ( Mss, Bss, Ass, Css, 'VariableNames', {'M', 'B', 'A', 'C'} );
end