function [fig, varargout] = plot(bs_obj, varargin)
%PLOT Plot BehaviourStateTable region(s): RK plane, D plane, or both.

p = inputParser;

% Validate user options
errorMsg = 'Specify the switches to plot at either ''RK_switch'', ''D_switch'' or ''both''';
switchSpecValidationFcn = @(x) assert(ismember(x, {'RK_switch', 'D_switch', 'both'})...
                                                            ,errorMsg);
paramRangeValidationFcn = @(x) assert(iscell(x),'specify axes limits as a cell array');

p.addParameter('switch', 'both', switchSpecValidationFcn);
p.addParameter('xLimits', {[0, 30], [0, 1]},paramRangeValidationFcn);
p.addParameter('yLimits', {[0, 30], [0, 1]},paramRangeValidationFcn);
p.addParameter('regionLabels', {}, @(x) assert(iscell(x) && length(x)==length(bs_obj), 'Specify labels as a cell array, of the same length as the behaviourTable object.'));
p.addParameter('hatchfill', []);
parse(p, varargin{:});

switchesToPlot = p.Results.switch;
regionLabels = p.Results.regionLabels;

if ismember(switchesToPlot, 'RK_switch')
    if iscell(p.Results.xLimits) && iscell(p.Results.yLimits)
        xLimitsRK = p.Results.xLimits{1};
        yLimitsRK = p.Results.yLimits{1};
    else
        xLimitsRK = p.Results.xLimits;
        yLimitsRK = p.Results.yLimits;
    end
elseif ismember(switchesToPlot, 'D_switch')
    if iscell(p.Results.xLimits) && iscell(p.Results.yLimits)
        xLimitsG = p.Results.xLimits{2};
        yLimitsG = p.Results.yLimits{2};
    else
        xLimitsG = p.Results.xLimits;
        yLimitsG = p.Results.yLimits;
    end
elseif ismember(switchesToPlot, 'both')
    xLimitsRK = p.Results.xLimits{1};
    yLimitsRK = p.Results.yLimits{1};
    xLimitsG = p.Results.xLimits{2};
    yLimitsG = p.Results.yLimits{2};
end

% Hatchfill patterns (if requested)
hatchfillParams = p.Results.hatchfill;
import figures.hatchfill.*;

if any(size(bs_obj)~=[1, 1])
    % we're plotting multiple behaviour regions on a single plane
    disp('Plotting multiple regions');
else
    % we're plotting just one region
    disp('Plotting a sinlge region');
end

if ismember(switchesToPlot, 'both')
    % we're plotting pair(s) of regions. One RK-switch region and the other a
    % D-switch region
    ax = subplot(1,2,1); % the RK-switch region(s)
    ax.NextPlot = 'add';
    elseif ismember(switchesToPlot, {'RK_switch', 'D_switch'}) % if we're just plotting one switch's bifurcation diagram
    ax = gca;
    ax.NextPlot = 'add';
end

if  ismember(switchesToPlot, {'both', 'RK_switch'})
    % entitle the figure with the name of the switch who's behaviour we're
    % plotting
    title = 'RK-switch region';
    ax.Title.String = title;
    ax.Title.Interpreter = 'latex';

    XYMax = [0, 0];
    num_label = 1;
    % make vector for polygon objects to be handed back to the caller
    h = [];
    for i=1:length(bs_obj)
        h = [h,plot(ax, bs_obj(i).RK_polygon)];

        % shade in the regions using hatching, stripes or speckles if asked
        if ~isempty(hatchfillParams)
            if strcmp('speckle',hatchfillParams{i,1})
                hatchfill(h(i), hatchfillParams{i,1});
            else
                hatchfill(h(i), hatchfillParams{i,:});
            end
        end

        % add text labels to each region
        [x, y] = centroid(bs_obj(i).RK_polygon);
        if isempty(regionLabels)
            label = string(num_label);
            num_label = num_label + 1;
        else
            label = regionLabels{i};
        end

        text(ax, x, y, label,...
                'interpreter', 'latex',...
                'FontSize', 14,...
                'BackgroundColor', 'w',...
                'HorizontalAlignment', 'center',...
                'VerticalAlignment', 'middle');
        ax.XLabel.String = '\kappa_M';
        ax.YLabel.String = '\alpha_M';
    end
    ax.XLim = xLimitsRK;
    ax.YLim = yLimitsRK;
end

%%
if ismember(switchesToPlot, 'both')
    ax = subplot(1,2,2); % the RK-switch region(s)
    ax.NextPlot = 'add';
end

if  ismember(switchesToPlot, {'both', 'D_switch'})
    % entitle the figure with the name of the switch who's behaviour we're
    % plotting
    title = 'D-switch region';
    ax.Title.String = title;
    ax.Title.Interpreter = 'latex';

    XYMax = [0, 0];
    num_label = 1;
    % make vector for polygon objects to be handed back to the caller
    h = [];
    for i=1:length(bs_obj)
        h = [h,plot(ax, bs_obj(i).D_polygon)];

        % shade in the regions using hatching, stripes or speckles if asked
        if ~isempty(hatchfillParams)
            if strcmp('speckle',hatchfillParams{i,1})
                hatchfill(h(i), hatchfillParams{i,1});
            else
                hatchfill(h(i), hatchfillParams{i,:});
            end
        end

        % add text labels to each region
        [x, y] = centroid(bs_obj(i).D_polygon);
        if isempty(regionLabels)
            label = string(num_label);
            num_label = num_label + 1;
        else
            label = regionLabels{i};
        end

        text(ax, x, y, label,...
                'interpreter', 'latex',...
                'FontSize', 14,...
                'BackgroundColor', 'w',...
                'HorizontalAlignment', 'center',...
                'VerticalAlignment', 'middle');
        ax.XLabel.String = '\kappa_B';
        ax.YLabel.String = '\delta_B';
    end
    ax.XLim = xLimitsG;
    ax.YLim = yLimitsG;
end
%%
fig = ax.Parent;
if nargout==2
    varargout{1} = h;
end
end