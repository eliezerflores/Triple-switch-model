function [network_vec,behaviour_region_index,n_networks_produced] = calculate_networks(behaviourState)
% CALCULATE_NETWORKS
% Converts BehaviourStateTable objects into discrete 8-state switch networks.
%
% Each BehaviourStateTable specifies, for all 8 switch configurations
% (RK, T, D), whether each switch wants to flip or stay fixed.
% This function translates those steady-state intentions into one or more
% transition networks.
%
% If multiple switches attempt to flip simultaneously (race conditions),
% multiple Network objects are generated, one per valid switch-ordering.

n_region_combinations = height(behaviourState);

% import the Network class for storing the network information
import NetworkAnalysis.Network;
network_vec = [];
behaviour_region_index = [];

n_networks_produced = zeros(n_region_combinations,1);

% Loop over all behaviour–state tables (parameter-space regions)
for i=1:n_region_combinations

    % Build transition matrices for this behaviour–state table
    % F : averaged transition matrix
    % F_separated_matrices : one matrix per race-resolution scenario
    % switch_order : switch priority ordering for each scenario
    [F, F_separated_matrices, switch_order] = calculate_transition_matrix(behaviourState(i));
    
    n_separated_matrices = length(F_separated_matrices);
    if n_separated_matrices==1
        disp('we''ve got a network with no initial condition dependences');
    end
    n_networks_produced(i) = n_separated_matrices;

    % Create one Network for each race-resolution scenario
    for k=1:n_separated_matrices
        network_vec = [network_vec;Network(F_separated_matrices{k}, switch_order(k,:), behaviourState(i), 'average_F', F, 'weight', 1/n_separated_matrices)];
    end

    % Record which behaviour–state table produced each network
    behaviour_region_index = [behaviour_region_index;repmat(i, n_separated_matrices,1)];
end
end

function [F, F_separated_matrices, switch_order] = calculate_transition_matrix(behaviourState_region)
% CALCULATE_TRANSITION_MATRIX
% Constructs the 8×8 transition matrix describing switch dynamics.
%
% Each state corresponds to a binary (RK, T, D) configuration.
% Entries in F encode allowed transitions between states.

F = sparse(8, 8);

% track of which switches win the race condition situations
race_condition_winner = categorical(NaN(8,8),1:3,{'RK_switch', 'T_switch', 'D_switch'});


% create an empty list which will hold the states where race conditions
% occur. This may end up holding between 0 and 8 (inclusive) of the
% conditions we test.
race_condition_state = [];

% Loop over all 8 switch configurations
for current_state=1:8
   
    % Determine which switches want to flip
    transition = table(false, false, false, 'VariableNames', {'RK_switch', 'T_switch', 'D_switch'});
    
    switch_names = ["RK_switch", "T_switch", "D_switch"];
   
    for name = switch_names
        state_col = strcat(name, '_state');
        behaviour_col = strcat(name, '_behaviour');
        
        this_state = behaviourState_region.behaviourState.(state_col)(current_state);
        this_behaviour = behaviourState_region.behaviourState.(behaviour_col)(current_state);
        
        % Behavioural rules for switch flipping
        if this_behaviour == 'B'
            transition.(name) = false;
        elseif this_behaviour == 'Ac'
            transition.(name) = true;
        elseif this_state == 0 && this_behaviour == 'Aon'
            transition.(name) = true;
        elseif this_state == 1 && this_behaviour == 'Aoff'
            transition.(name) = true;
        else
            transition.(name) = false;
        end
    end

    n_switches_transitionsing = sum(transition{1,:});
    
    % Current switch configuration
    current_switchStates = behaviourState_region.behaviourState(current_state,append(switch_names, '_state'));
    current_switchStates.Properties.VariableNames = erase(current_switchStates.Properties.VariableNames,'_state'); % remove the "_state" postfix in the column names
    
    % Case 1: no switches flip → absorbing state
    if n_switches_transitionsing==0 % we're at a stable steady state
        F(current_state,current_state) = 1; % no transition, so stay on this node.
   
    % Case 2: exactly one switch flips → deterministic transition (register
    % the transition and move on)
    elseif n_switches_transitionsing==1 

        next_switchState = current_switchStates;
        % get logical indexing of which switch to flip
        li_sw_flp = transition{1,:} == true;
        % get the name of the switch that will flip
        sw_flp = switch_names(li_sw_flp);
        % finally, flip the switch
        next_switchState.(sw_flp) = ~next_switchState.(sw_flp);
        % calculate the index of the next switch state
        next_state = bits2index(next_switchState);
        F(current_state, next_state) = 1;

        % Case 3: multiple switches flip → race condition
    elseif n_switches_transitionsing>1 

        race_condition_state = vertcat(race_condition_state,current_state);
        
        % record candidate switches next states (flip each candidate switch
        % separately)
        next_switchState = repmat(current_switchStates,n_switches_transitionsing,1);
        % get logical indexing of which switch to flip
        li_sw_flp = transition{1,:};
        sw_flp = switch_names(li_sw_flp);
       
        
        for k=1:n_switches_transitionsing
            next_switchState.(sw_flp(k))(k) = ~next_switchState.(sw_flp(k))(k);
        end

        next_state = bits2index(next_switchState);
        
        % store all candidate edges for now; later we split into separate
        % networks by choosing a winner ordering for each race condition
        F(current_state, next_state) = 1/n_switches_transitionsing;
        
        for i=1:length(next_state)
            race_condition_winner(current_state, next_state(i)) = sw_flp(i);
        end
    end
end


% --- Split F into one or more matrices by resolving race conditions ---
% If 2 or 3 switches appear in races across the graph, enumerate possible
% winner orderings and produce one transition matrix per ordering.
n_competing_switches = any(race_condition_winner == 'RK_switch', 'all') +...
    any(race_condition_winner == 'T_switch', 'all') +...
    any(race_condition_winner == 'D_switch', 'all');

if n_competing_switches == 3
    
    % Six possible winner orderings when all three switches can race:
    % RK-switch | T-switch | D-switch
    %-----------+----------+----------
    % 1st       | 2nd      | 3rd
    % 2nd       | 3rd      | 1st
    % 3rd       | 1st      | 2nd
    % 1st       | 3rd      | 2nd
    % 3rd       | 2nd      | 1st
    % 2nd       | 1st      | 3rd
    switch_order = table([1;2;3;1;3;2],[2;3;1;3;2;1],[3;1;2;2;1;3], 'VariableNames', {'RK_switch', 'T_switch', 'D_switch'});
    
    F_separated_matrices = cell(1, 6);

    for k=1:6
        F_separated_matrices{k} = F;
    end
    for i = 1:8
        % work through each row of the record of the race conditions we've
        % been building up, and when a transition occurs where a race
        % condition is present, allocate the winners according to each row
        % of the "switch order" table.
        if any( ~isundefined(race_condition_winner(i, :)) ) % if any of the race conditions exist at this transition
            RK_present = any(race_condition_winner(i, :)=='RK_switch');
            T_present  = any(race_condition_winner(i, :)=='T_switch');
            G_present  = any(race_condition_winner(i, :)=='D_switch');
            
            for chk=1:6
                % keep only the edge for the highest-priority switch in
                % this ordering
                for rank = 1:3
                    if RK_present && switch_order.RK_switch(chk)==rank
                        if any(race_condition_winner(i, :)=='RK_switch')
                            F_separated_matrices{chk}(i,find(race_condition_winner(i, :)=='RK_switch')) = 1;
                        end
                        if any(race_condition_winner(i, :)=='T_switch')
                            F_separated_matrices{chk}(i,find(race_condition_winner(i, :)=='T_switch'))  = 0;
                        end
                        if any(race_condition_winner(i, :)=='D_switch')
                            F_separated_matrices{chk}(i,find(race_condition_winner(i, :)=='D_switch'))  = 0;
                        end
                    elseif T_present && switch_order.T_switch(chk)==rank
                        if any(race_condition_winner(i, :)=='RK_switch')
                            F_separated_matrices{chk}(i,find(race_condition_winner(i, :)=='RK_switch')) = 0;
                        end
                        if any(race_condition_winner(i, :)=='T_switch')
                            F_separated_matrices{chk}(i,find(race_condition_winner(i, :)=='T_switch'))  = 1;
                        end
                        if any(race_condition_winner(i, :)=='D_switch')
                            F_separated_matrices{chk}(i,find(race_condition_winner(i, :)=='D_switch'))  = 0;
                        end
                    elseif G_present && switch_order.D_switch(chk)==rank
                        if any(race_condition_winner(i, :)=='RK_switch')
                            F_separated_matrices{chk}(i,find(race_condition_winner(i, :)=='RK_switch')) = 0;
                        end
                        if any(race_condition_winner(i, :)=='T_switch')
                            F_separated_matrices{chk}(i,find(race_condition_winner(i, :)=='T_switch'))  = 0;
                        end
                        if any(race_condition_winner(i, :)=='D_switch')
                            F_separated_matrices{chk}(i,find(race_condition_winner(i, :)=='D_switch'))  = 1;
                        end
                    end
                end
            end
        end
    end

elseif n_competing_switches == 2
    
    % 2. There are two possible winner orderings when exactly two switches
    % can race
    
    F_separated_matrices = cell(1, 2);
    for k=1:2
        F_separated_matrices{k} = F;
    end
    RK_present = any(race_condition_winner=='RK_switch', 'all');
    T_present  = any(race_condition_winner=='T_switch' , 'all');
    G_present  = any(race_condition_winner=='D_switch' , 'all');
    
    if RK_present && T_present
        switch_order = table([NaN;NaN],[1;2],[2;1], 'VariableNames', {'D_switch','RK_switch', 'T_switch'});
        
        F_separated_matrices{1}(race_condition_winner=='RK_switch') = 1;
        F_separated_matrices{1}(race_condition_winner=='T_switch')  = 0;
        
        F_separated_matrices{2}(race_condition_winner=='RK_switch') = 0;
        F_separated_matrices{2}(race_condition_winner=='T_switch')  = 1;
    elseif T_present && G_present
        switch_order = table([NaN;NaN],[1;2],[2;1], 'VariableNames', {'RK_switch','T_switch','D_switch'});
        
        F_separated_matrices{1}(race_condition_winner=='T_switch')  = 1;
        F_separated_matrices{1}(race_condition_winner=='D_switch')  = 0;
        
        F_separated_matrices{2}(race_condition_winner=='T_switch')  = 0;
        F_separated_matrices{2}(race_condition_winner=='D_switch')  = 1;
    elseif G_present && RK_present
        switch_order = table([NaN;NaN],[1;2],[2;1], 'VariableNames', {'T_switch','D_switch','RK_switch'});
        
        F_separated_matrices{1}(race_condition_winner=='D_switch')  = 1;
        F_separated_matrices{1}(race_condition_winner=='RK_switch') = 0;
        
        F_separated_matrices{2}(race_condition_winner=='D_switch')  = 0;
        F_separated_matrices{2}(race_condition_winner=='RK_switch') = 1;
    else
        error('This should not occur.');
    end

elseif n_competing_switches == 1
    error('This case should not occur.');

elseif n_competing_switches == 0
    % No races anywhere -> single deterministic network
    switch_order = table(1,1,1,'VariableNames',{'RK_switch','T_switch','D_switch'}); % not used
    F_separated_matrices = {F};
end
end


function index = bits2index(state)
% Map (RK,T,D) in {0,1}^2 to state index 1..8
index = 4 * state.RK_switch + 2 * state.T_switch + state.D_switch + 1;
end
