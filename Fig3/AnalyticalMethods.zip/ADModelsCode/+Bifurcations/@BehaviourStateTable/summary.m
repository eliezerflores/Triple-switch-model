function summaryTable = summary(obj)
% SUMMARY Create a summary table of behaviour states across regions.

n_switchStates_per_region = 8;

% Number of regions represented by the object array
n_regions = length(obj);

if n_regions>1
    % Create region index repeated for each switch state
    reg_number = table(repelem((1:n_regions)',n_switchStates_per_region,1),'VariableNames', {'Region_number'});
    summaryTable = [reg_number,vertcat(obj.behaviourState)];
else
    summaryTable = obj.behaviourState;
end
end