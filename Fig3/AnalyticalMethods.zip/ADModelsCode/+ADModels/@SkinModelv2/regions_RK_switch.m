function outputstruct = regions_RK_switch(obj,kappa_M_Lim, alpha_M_Lim,varargin)
%regions_RK_switch Method to calculate the behaviour regions of
%the RK-switch bifurcation diagram

p = inputParser;
p.addParameter('check', true, @islogical);
p.parse(varargin{:});
check = p.Results.check;

% Name the threshold values and switch values as variables within the scope
% of this function for clarity.(We could refer to each of these through the
% object, but it would be more difficult to read and maintain the code.)

D_off = obj.DFunction.off;
D_on = obj.DFunction.on;

R_off = obj.RFunction.off;
R_on  = obj.RFunction.on;
K_off = obj.KFunction.off;
K_on  = obj.KFunction.on;
T_off = obj.TFunction.off;
% T_on  = obj.TFunction.on; % T switch values not used here
% T_m = obj.TFunction.m; 

Mminus = obj.switchValues.RK_switch('00', 1); % note the 00 here is just an arbitrary selection as the RK-switch thresholds are not affected by the states of the other switches
Mplus  = obj.switchValues.RK_switch('00', 2);

%% calculate bifurcation diagram with D_off
% BE line for RK-switch off --> on
[m_turn_on_D_off, c_turn_on_D_off] = obj.BE_line_RK_plane(R_off,K_off,T_off,D_off,Mplus);

% BE line for RK-switch on --> off
[m_turn_off_D_off, c_turn_off_D_off] = obj.BE_line_RK_plane(R_on,K_on,T_off,D_off,Mminus);


%% calculate polyshapes for each region in the D_off diagram
switchStates_D_off = table(false, NaN, 'VariableNames', {'D_switch','T_switch'}); % The NaN represents the independence of the RK-switch bifurcation diagram on the T-switch state.
[shapes_D_off, turn_off_D_off, turn_on_D_off] = obj.calculate_regions('kappa_M','alpha_M',kappa_M_Lim, alpha_M_Lim, m_turn_on_D_off, c_turn_on_D_off, m_turn_off_D_off, c_turn_off_D_off, 'RK_switch', switchStates_D_off,'check',check);
%% calculate bifurcation diagram with D_on
% BE line for RK-switch off --> on
[m_turn_on_D_on, c_turn_on_D_on] = obj.BE_line_RK_plane(R_off,K_off,T_off,D_on,Mplus);

% BE line for RK-switch on --> off
[m_turn_off_D_on, c_turn_off_D_on] = obj.BE_line_RK_plane(R_on,K_on,T_off,D_on,Mminus);

switchStates_D_on = table(true,NaN, 'VariableNames', {'D_switch','T_switch'});
[shapes_D_on, turn_off_D_on, turn_on_D_on]  = obj.calculate_regions('kappa_M','alpha_M',kappa_M_Lim, alpha_M_Lim, m_turn_on_D_on, c_turn_on_D_on, m_turn_off_D_on, c_turn_off_D_on, 'RK_switch', switchStates_D_on,'check',check);

%% calculate the polygons for the bifurcation diagram representing the change when the other switch turns on
shapes_overlap = obj.overlap_regions(shapes_D_off, shapes_D_on,'check', check);
outputstruct = struct('D_off', shapes_D_off,...
                    'D_on', shapes_D_on,...
                    'overlap', shapes_overlap, ...
        'turn_on_D_off', turn_on_D_off, ...
        'turn_off_D_off', turn_off_D_off, ...
        'turn_on_D_on', turn_on_D_on, ...
        'turn_off_D_on', turn_off_D_on);
end