classdef BehaviourStateTable
    % BEHAVIOURSTATETABLE 
    % Combines one RK-switch BehaviourRegion and one D-switch BehaviourRegion
    % into a full 8-state table of switch states and qualitative behaviours.

    
    properties
        RK_polygon (1,1) polyshape
        D_polygon (1,1) polyshape
        
        behaviourState (8,6) table = table(NaN(8,1),NaN(8,1),NaN(8,1),NaN(8,1),NaN(8,1),NaN(8,1),'VariableNames', {'RK_switch_state', 'T_switch_state', 'D_switch_state', 'RK_switch_behaviour', 'T_switch_behaviour', 'D_switch_behaviour'});
        
        parameters (1,:) table % table containing ODE parameters (at the centroid of the regions for kappa_M, alpha_M, kappa_B and delta_B).
        switchValues table % table containing the switch threshold values
        RFunction table % table of values for the R-switch at each state (off or on)
        KFunction table % table of values for the K-switch at each state (off or on)
        TFunction table % table of values for the T-switch at each state (off, on)
        DFunction table % table of values for the D-switch at each state (off or on)

        vol
    end
    
    methods
        function obj = BehaviourStateTable(RK_region, D_region)
            % BEHAVIOURSTATETABLE Construct a vector of behaviour-state
            %tables, summarising the RK- and D-switch behaviour regions at
            %the imput.
            
            if ~isa(RK_region, 'Bifurcations.BehaviourRegion')
                error('we need a ''Bifurcations.BehaviourRegion'' to define the RK-region(s).');
            end
            if ~isa(D_region, 'Bifurcations.BehaviourRegion')
                error('we need a ''Bifurcations.BehaviourRegion'' to define the D-region(s).');
            end
            
            % Ensure both regions refer to the same underlying model settings.
            for i=RK_region.model.parameters.Properties.VariableNames
                p_name = string(i);
                if any(strcmp(p_name, {'kappa_M','alpha_M'})) % if we're looking at the bifurcation paramters for the RK-switch, we expect these to change for the RK-regions, and know the values don't affect the D-switch regions, so we just set them to be equal to the RK-region's centroid values.
                    D_region.model.parameters.(p_name) = RK_region.model.parameters.(p_name);
                end
                param_matches = RK_region.model.parameters.(p_name)==D_region.model.parameters.(p_name);
                if ~param_matches
                    error('The parameter value %s does not match between the behaviour regions provided', p_name);
                end
            end
            if any(D_region.model.switchValues{:,:}~=RK_region.model.switchValues{:,:}, 'all')
                error('Switch values do not match');
            end
            if any(D_region.model.RFunction{:,:}~=RK_region.model.RFunction{:,:}, 'all')
                error('RFunction values do not match');
            end
            if any(D_region.model.KFunction{:,:}~=RK_region.model.KFunction{:,:}, 'all')
                error('KFunction values do not match');
            end
            if any(D_region.model.TFunction{:,:}~=RK_region.model.TFunction{:,:}, 'all')
                error('TFunction values do not match');
            end
            if any(D_region.model.DFunction{:,:}~=RK_region.model.DFunction{:,:}, 'all')
                error('DFunction values do not match');
            end
            obj.parameters = RK_region.model.parameters;
            obj.switchValues = RK_region.model.switchValues;
            obj.RFunction = RK_region.model.RFunction;
            obj.KFunction = RK_region.model.KFunction;
            obj.TFunction = RK_region.model.TFunction;
            obj.DFunction = RK_region.model.DFunction;
            
            obj.RK_polygon = RK_region.polygon;
            obj.D_polygon  = D_region.polygon;

            obj.vol = area(obj.RK_polygon) * area(obj.D_polygon); 
            
            % Assumption: T-switch behaviour follows RK-switch state
            % RK_switch_state    T_switch_behaviour
            % _______________    __________________
            %
            %        0                   Aoff
            %        1                   Aon

            behavs = cellstr({'Aoff','Hd','Ac','Aon'});
            
            T_bs  = table([false;true],categorical({'Aoff';'Aon'},behavs),'VariableNames', {'RK_switch_state','T_switch_behaviour'});
            
            % Summaries from the two regions (each encode behaviours over
            % states)
            RK_bs = RK_region.summary;
            D_bs  = D_region.summary;
            
            % Stack RK table to match the join structure
            RK_bs_stacked = [table([false;false;true;true],'VariableNames', {'RK_switch_state'}),[RK_bs;RK_bs]];
            try obj.behaviourState = innerjoin(join(D_bs,T_bs),RK_bs_stacked);
            catch
                error('debug');
            end
        end
        
        function obj = set.behaviourState(obj,behaviourState_in)
            %  Enforce consistent column ordering: configurations first (RK,T,D), then behaviours (RK,T,D).
            behaviourState_in = movevars(behaviourState_in,'T_switch_behaviour','Before','D_switch_behaviour');
            behaviourState_in = movevars(behaviourState_in,'RK_switch_behaviour','Before','T_switch_behaviour');
            behaviourState_in = movevars(behaviourState_in,'D_switch_state','Before','RK_switch_behaviour');
            behaviourState_in = movevars(behaviourState_in,'T_switch_state','Before','D_switch_state');
            behaviourState_in = movevars(behaviourState_in,'RK_switch_state','Before','T_switch_state');
            
            obj.behaviourState = behaviourState_in;
        end
        
        behaviourState = summary(obj)
        [fig,varargout] = plot(obj, varargin);
        [fig,varargout] = plot_mapping(obj, varargin);

       function bs_view = viewBioBehaviourState(obj)
       % Returns a behaviour-state table with:
       % D_switch_state: true <-> false (logical)
       % D_switch_behaviour: 'Aoff' <-> 'Aon'
       % Does NOT modify obj.behaviourState.

        bs = obj.behaviourState;   % copy only
        bs.D_switch_state = ~bs.D_switch_state;

        g = categorical(bs.D_switch_behaviour);   % force categorical
        g(g == 'Aoff') = 'Aon';
        g(g == 'Aon') = 'Aoff';
        bs.D_switch_behaviour = g;

        bs_view = bs;
        end

       
        function tf = eq(obj1, obj2)
            % Check for equality: behaviourState tables match exactly (elementwise).
            tf = true(size(obj1));

            % column names are:
            colNames = string(obj1(1).behaviourState.Properties.VariableNames); % make it a string array (helps with indexing in the for loop)
            for obj1Index = 1:length(obj1)
                % we assume they are equal, and then check each column
                for col = colNames
                    if ~all(obj1(obj1Index).behaviourState.(col) == obj2.behaviourState.(col))
                        tf(obj1Index) = false;
                        break; % we've found a difference, so break out of the col=colNames for loop as we know they are not equal
                    end
                end
            end
        end

        function tf = ne(obj1, obj2)
            tf = ~eq(obj1,obj2);
        end
    end
end