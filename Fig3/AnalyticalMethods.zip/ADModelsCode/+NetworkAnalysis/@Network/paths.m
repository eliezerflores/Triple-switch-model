function out_pths = paths(obj, varargin)
% PATHS Calculate the paths through each Network.
% 
% For each Network, we generate up to 8 paths (one per starting state),
% ending at either an absorbing state or entry into an absorbing loop.
% Options allow repeating transient loops and absorbing loops for plotting.

%% Parse options
p = inputParser;
p.addParameter('repeat_absorbing_loops', 1, @(x) isnumeric(x) && x>0); % this specifies the minimum number of repeats we would like to see from each absorbing loop we identify.
p.addParameter('repeat_transient_loops', 1, @(x) isnumeric(x) && x>=0); % specifies the number of times we would like to see absorbing loops in our paths. We can set this to 0 if we want to ignore them entirely.

parse(p, varargin{:});
repeat_absorbing_loops = p.Results.repeat_absorbing_loops;
repeat_transient_loops = p.Results.repeat_transient_loops;

%% Support vector inputs: return stacked paths for all Network objects
N = length(obj);
% first, we reallocate a cell array to store all the paths through the N
% network objects. There will be 8 paths produced per network (starting
% configs 1..8)

pths = cell(8*N, 1);
pths_index_start = 1;
for ind_O = 1:N
    
    %% Build a digraph used for path finding
    % If transient loops exist, remove the loop edges so allpaths() does
    % not get stuck, and add "exit" edges that represent eventual escape.

    if obj(ind_O).num_transient_loops>0 
        G_digraph = obj(ind_O).G;

        if ~isprop(obj(ind_O), 'transient_loops_table') % this check ensures any old network objects created before this property was a thing have it added by the updated "classify" method.
            obj(ind_O) = obj(ind_O).classify;
        end
        G_digraph = rmedge(G_digraph, obj(ind_O).transient_loops_table.EndNodes);

  
        if ~isprop(obj(ind_O), 'transient_loop_exits_table') % this check ensures any old network objects created before this property was a thing have it added by the updated "classify" method.
            obj(ind_O) = obj(ind_O).classify;
        end
        G_digraph = addedge(G_digraph, obj(ind_O).transient_loop_exits_table);
    else % if no transient loops exist
        % we can safely leave the digraph object
        % as it is
        G_digraph = obj(ind_O).G;
    end

    num_absorbing_states = obj(ind_O).num_absorbing_states;
    num_absorbing_loops = obj(ind_O).num_absorbing_loops;
    num_transient_loops = obj(ind_O).num_transient_loops;

    absorbing_loops = obj(ind_O).absorbing_loops;

    %% Define start and end targets for path enumeration
    vec_starting_configs  = 1:8;

    % End targets: all absorbing states, plus one representative node from
    % each absorbing loop (any node works as a target).
    vec_ending_configs = [obj(ind_O).absorbing_states, zeros(1, num_absorbing_loops)];
    for k=1:num_absorbing_loops
        vec_ending_configs(num_absorbing_states + k) = obj(ind_O).absorbing_loops{k}(1); % just pick the first element from the absorbing loop as our target. We're guarunteed to reach it in our pathway eventually.
    end

   
    %% Compute transient paths (up to entry into absorbing state/loop)
    this_pths = calculate_transients_fun(G_digraph, vec_starting_configs, vec_ending_configs, absorbing_loops);

    %% For visualizing transient loops by inserting extra laps
    if num_transient_loops>0
        this_pths = repeat_transient_loops_fun(this_pths, repeat_transient_loops);
    end

    %% Append extra laps around abosorbing loops (for plotting)
    if num_absorbing_loops>0
        this_pths = repeat_absorbing_loops_fun(this_pths, absorbing_loops, num_absorbing_loops, repeat_absorbing_loops);
    end

    %% Store 8 paths for this network
    pths_index = pths_index_start:(pths_index_start+7);
    pths_index_start = pths_index_start + 8;
    for i=1:length(pths_index)
        pths{pths_index(i)} = this_pths{i};
    end
end

%% at this point, we have all the paths through this network organised as vectors in cell array pths
% now we just need to organise the results better for plotting

% The problem we face now is that each of the 8 paths we've found are in
% general different lengths. We must pad the end of the short paths to make
% them all the same length.

%% Pad paths to equal length so they can be plotted as a matrix/heatmap
max_path_length = 0;
for i=1:(8*N)
    max_path_length = max(max_path_length, length(pths{i}));
end

pths_index_start = 1;
for obj_i=1:N
    pths_index = pths_index_start:(pths_index_start+7);
    pths_index_start = pths_index_start + 8;
    
    this_pths = make_all_paths_same_length(pths(pths_index), max_path_length,...
                                            obj(obj_i).absorbing_states,...
                                            obj(obj_i).absorbing_loops,...
                                            obj(obj_i).num_absorbing_loops);
    for i=1:length(pths_index)
        pths{pths_index(i)} = this_pths{i};
    end
end


%% Stack into an (8N by T) matrix

out_pths = zeros(8*N, max_path_length);

for i=1:8*N
    out_pths(i,:) = pths{i};
end
end

function pths_out = calculate_transients_fun(G_digraph, vec_starting_configs, vec_ending_configs, absorbing_loops)
%CALCULATE_TRANSIENTS_FUN Find a representative path from each start state
% to each end target (absorbing state or loop representative).
%
% at the end of this section, we produce a cell array called "pths", which
% contains vectors representing the sequence of configurations up to and
% including the first absorbing configuration or entry configuration in an
% absorbing loop.
i = 1;
for k = 1:length(vec_ending_configs)
    end_config = vec_ending_configs(k);
    max_lngth_transient = 0;
    for start_config = vec_starting_configs
        this_pth = allpaths(G_digraph, start_config, end_config);

        if isempty(this_pth)
            continue;
        else
            % allpaths returns a cell; take the first path found
            this_pth = this_pth{1};
            pth_lngth = length(this_pth);

            % If end_config lies in an absorbing loop, cut path at loop
            % entry
            for this_absorbing_loop = absorbing_loops
                config_is_in_absorbing_loop = ismember(this_pth,this_absorbing_loop{1});
                n_configs_in_absorbing_loop = sum(config_is_in_absorbing_loop);
                if n_configs_in_absorbing_loop>1
                    this_pth(pth_lngth-n_configs_in_absorbing_loop+2:end) = [];
                end
            end

            if max_lngth_transient<pth_lngth
                max_lngth_transient = pth_lngth;
            end


            pths_out{i} = this_pth;
            i = i + 1;
        end
    end
end
end

function pths_out = repeat_transient_loops_fun(pths, repeat_transient_loops)
%%REPEAT_TRANSIENT_LOOPS_FUN Insert extra laps around transient loops.
% This is purely for visualization (e.g. making oscialltions explicit).

pths_out = cell(size(pths));
for i=1:length(pths)
    is_start_of_transient_34 = ismember(pths{i}, [3,4]);
    is_start_of_transient_56 = ismember(pths{i}, [5,6]);
    if any(is_start_of_transient_34)
        % find the exact location where this occurs
        ind_of_transient = find(is_start_of_transient_34, 1, 'last');

        % If we pass through configuration 4, the loop we must add
        % should be [3, 4] in that order.
        % If we pass through configuration 3, the loop is instead [4,
        % 3] in that order.
        if pths{i}(ind_of_transient)==4
            this_loop = [3,4];
        elseif pths{i}(ind_of_transient)==3
            this_loop = [4,3];
        end
    elseif any(is_start_of_transient_56)
        % find the exact location where this occurs
        ind_of_transient = find(is_start_of_transient_56, 1, 'last');

        if pths{i}(ind_of_transient)==6
            this_loop = [5,6];
        elseif pths{i}(ind_of_transient)==5
            this_loop = [6,5];
        end
    else
        pths_out{i} = pths{i}; % if there's no transient in this specific path, just pass it through to the output unchanged
        continue;
    end
    try pths_out{i} = [pths{i}(1:ind_of_transient), repmat(this_loop, 1, repeat_transient_loops), pths{i}(ind_of_transient+1:end)];
    catch
        disp('debug');
    end
end
end

function pths_out = repeat_absorbing_loops_fun(pths, absorbing_loops, num_absorbing_loops, repeat_absorbing_loops)
%% REPEAT_ABSORBING_LOOPS_FUN Append extra laps around absorbing loops.
% Useful for plotting a longer "steady oscillation" tail.

pths_out = cell(size(pths));

% we identify the final configuration in each path, and check if it
% belongs to one of these absorbing loops
for i=1:length(pths)
    final_config = pths{i}(end);
    for ind_of_loop = 1:num_absorbing_loops
        this_absorbing_loop = absorbing_loops{ind_of_loop};
        is_entry_node = ismember(this_absorbing_loop,final_config);
        if ~any(is_entry_node)
            pths_out{i} = pths{i}; % nothing to add, so just pass the path through to the output unchanged
            continue; % the final configuration didn't appear in this absorbing loop, so continue to the next round of this for loop
        end
        index_of_entry = find(is_entry_node);
        this_absorbing_loop = circshift(this_absorbing_loop, -index_of_entry);
        pths_out{i} = [pths{i}, repmat(this_absorbing_loop, 1, repeat_absorbing_loops)];
        break; % tells MATLAB not to bother checking the other potential absorbing loops. We've already found what we need.
    end
end
end


function pths_out = make_all_paths_same_length(pths, desired_length, absorbing_states, absorbing_loops, num_absorbing_loops)
%% MAKE_ALL_PATHS_SAME_LENGTH Pad each path to desired length.
% If the path ends in an absorbing state, repeat that state.
% If it ends in an absorbing loop, continue cycling around the loop.

pths_out = cell(size(pths));

for i=1:length(pths)
    final_config = pths{i}(end);
    pth_length = length(pths{i});
    n_extra_configs_required = desired_length-length(pths{i});

    if pth_length<desired_length
        if ismember(final_config, absorbing_states)
            pths_out{i} = [pths{i}, repmat(final_config, 1, n_extra_configs_required)];
        else % else it must be a configuration in an abosorbing loop
            % identify which loop
            for ind_of_loop = 1:num_absorbing_loops
                this_absorbing_loop = absorbing_loops{ind_of_loop};
                is_start_node = ismember(this_absorbing_loop,final_config);
                if ~any(is_start_node)
                    continue; % if the final configuration didn't appear in this absorbing loop, continue to the next round of this for loop
                end
                index_of_entry = find(is_start_node);
                this_absorbing_loop = circshift(this_absorbing_loop, -index_of_entry);
                break; % tells MATLAB not to bother checking the other potential absorbing loops. We've already found what we need.
            end
            ind_of_absorbing_loop = mod((1:n_extra_configs_required)-1, length(this_absorbing_loop))+1;
            pths_out{i} = [pths{i}, this_absorbing_loop(ind_of_absorbing_loop)];
        end
    else
        pths_out{i} = pths{i}; % if the path is already the desired length, just pass it through this function undesturbed.
    end
end

end