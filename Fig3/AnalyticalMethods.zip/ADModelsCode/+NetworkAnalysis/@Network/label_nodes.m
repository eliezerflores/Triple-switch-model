function ax = label_nodes(obj, ax, XLoc, YLoc, width, nodeLabels)
% draw a rectangle at each node, with width and height appropriate to frame
% the switch state illustration.
ax.NextPlot = 'add';
for i=1:8
    if ~isempty(nodeLabels{i})
        XLocs = [XLoc(i)-width/2,XLoc(i)-width/2,XLoc(i)+width/2,XLoc(i)+width/2,XLoc(i)-width/2];
        YLocs = [YLoc(i)-width/6,YLoc(i)+width/6,YLoc(i)+width/6,YLoc(i)-width/6,YLoc(i)-width/6];
        pgon = polyshape(XLocs,YLocs);
        
        nodeLab = plot(ax, pgon);
        nodeLab.FaceColor = 'blue';
        nodeLab.FaceAlpha = 1;
        pg(i).EdgeColor = 'k';
        pg(i).LineWidth = 0.8;
    end
end

end