classdef BehaviourRegion
    % BehaviourRegion
    % A labelled polygonal region in a bifurcation plane where the behaviour
    % of a target switch is constant (e.g. Aoff / Hd / Ac / Aon).

    properties
        polygon (1,1) polyshape            % Region boundary in parameter space
        behaviour (:,1) table              % Behaviour label(s) for the target switch in this region
        switchStates table                 % Fixed states of the other switch(es) used when defining this region

        x_variable_name char               % Parameter name on x-axis (e.g. 'kappa_M')
        y_variable_name char               % Parameter name on y-axis (e.g. 'alpha_M')
        
        model % the hybrid-dynamical system model which creates this behaviour region
    end
   

    methods
        function obj = BehaviourRegion(polygon, x_variable_name, y_variable_name, behaviour, switchStates, model_obj, varargin)
            % Construct a BehaviourRegion from a polygon + labels.

            
            if nargin==0
                return
            end
            

            p = inputParser;
            p.addRequired('polygon', @(x) isa(x,'polyshape') );
            p.addRequired('x_variable_name', @ischar);
            p.addRequired('y_variable_name', @ischar);
            p.addRequired('behaviour', @istable );
            p.addRequired('switchStates', @istable );
            
            p.addRequired('model_obj', @(x) isa(x, 'ADModels.SkinModelv2') | isa(x,'ADModels.ADGSwitchModel') | isa(x,'ADModels.DoubleSwitchModelV2') | isa(x,'ADModels.DoubleSwitchModelV3'))
            
            
            p.addParameter('check', true, @islogical);
            
            p.parse(polygon, x_variable_name, y_variable_name, behaviour, switchStates, model_obj, varargin{:})
            
            obj.polygon      = p.Results.polygon;
            obj.x_variable_name  = p.Results.x_variable_name;
            obj.y_variable_name  = p.Results.y_variable_name;
            obj.behaviour    = p.Results.behaviour;
            obj.switchStates = p.Results.switchStates;
            
            check = p.Results.check;
            
            % Store a reference model; the set method also updates model
            % parameters to the polygon centroid.
            obj.model        = p.Results.model_obj;
            
            if check
                obj.check_region_behaviours;
            end
        end
        
        function obj = set.behaviour(obj, behaviour)
            if ~istable(behaviour)
                error('Please specify the behaviours as a table');
            end
            switchNames = behaviour.Properties.VariableNames;
            present = ismember ( switchNames, {'RK_switch','D_switch'} );
            if length(switchNames)~=1 || sum(present)~=1
                error('We need exactly one switches'' behaviour to be specified for each behaviour region');
            end
            obj.behaviour = behaviour;
        end
        
        function obj = set.switchStates(obj, switchStates)
            if ~istable(switchStates)
                error('Please specify the switch states as a table');
            end
            switchNames = switchStates.Properties.VariableNames;
            present = ismember ( switchNames, {'RK_switch','T_switch','D_switch'} );
            if length(switchNames)~=sum(present)
                error('We need exactly one or two switches'' states to be specified for each behaviour region.');
            end
            obj.switchStates = switchStates;
        end
        
        function obj = set.model(obj, model)
            % Set the reference model and update its (x,y) parameters to the
            % centroid of this region.
            if ~all(ismember({obj.x_variable_name,obj.y_variable_name},model.parameters.Properties.VariableNames)) % checks that both xVar and yVar appear in the list of parameter names
                error('The xVar and yVar parameter names must appear in the parameter names list of the model.');
            end
          
            [xCentroid, yCentroid] = centroid(obj.polygon);
            model.parameters.(obj.x_variable_name) = xCentroid;
            model.parameters.(obj.y_variable_name) = yCentroid;
            
            obj.model = model;
        end
        
        [fig,varargout] = plot(obj, varargin);

        valid = check_region_behaviours(obj)
        
        summaryTable = summary(obj)
    end
end
