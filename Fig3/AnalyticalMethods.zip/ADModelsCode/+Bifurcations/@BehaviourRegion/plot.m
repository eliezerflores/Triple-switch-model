function [fig, varargout] = plot(br_obj, varargin)
%PLOT Method to plot a vector of BehaviourRegion objects (polyshapes)

p = inputParser;
p.addParameter('hatchfill', []);
p.addParameter('distribution', false);
p.addParameter('title', []);
parse(p, varargin{:});

distribution = p.Results.distribution;
title = p.Results.title;

% Optional hatchfill styling (stripes/speckle/etc.)
hatchfillParams = p.Results.hatchfill;
if ~isempty(hatchfillParams)
    import figures.hatchfill.*;
end

if distribution
    disp('We haven''t yet produced code to show the distribution of regions');
elseif any(size(br_obj)~=[1, 1])
    % we're plotting multiple behaviour regions on a single plane
    disp('Plotting multiple regions');
else
    % we're plotting just one region
    disp('Plotting a sinlge region');
end

ax = gca;
ax.NextPlot = 'add';
% check the switch states for this diagram
% we have one of two situations
% 1. We're plotting the bifurcation diagram for a stationary switch
% configuration
% 2. We're plotting the bifurcation diagram for a changing switch
% configuration
% These cases may be distinguished by the height of the table
% br_obj.switchStates
n_configs = height(br_obj(1).switchStates);
the_other_switches = br_obj(1).switchStates.Properties.VariableNames;
state_of_other_switches = br_obj(1).switchStates{:,:};

if n_configs==1
    % we're dealing with a stationary switch state configuration, so just
    % label the plot with the state of the switches.
    if length(the_other_switches)==1
        % we must be dealing with the RK-switch diagram which has no
        % dependence on the T-switch (hence the NaN in the T-switch state
        % listing).
        if state_of_other_switches==false
            status = 'off';
        else
            status = 'on';
        end
        subtitle = strrep(sprintf('%s %s', string(the_other_switches), status), '_', '-');
    else
        % we must be dealing with the D-switch diagram which depends on the
        % state of both of the other switches (RK- and T-switch).
        if state_of_other_switches(1)==false
            status1 = 'off';
        else
            status1 = 'on';
        end
        if state_of_other_switches(2)==false
            status2 = 'off';
        else
            status2 = 'on';
        end
        subtitle = strrep(sprintf('%s %s, %s %s', string(the_other_switches(1)), status1, string(the_other_switches(2)), status2), '_', '-');
    end

elseif n_configs==2
    % we're dealing with a diagram showing how the BE bifurcation lines
    % move in response to switch transition
    if length(the_other_switches)==1
        % we must be dealing with the RK-switch diagram which has no
        % dependence on the T-switch (hence the NaN in the T-switch state
        % listing).
        if state_of_other_switches(1)==false
            status1 = 'off';
        else
            status1 = 'on';
        end
        if state_of_other_switches(2)==false
            status2 = 'off';
        else
            status2 = 'on';
        end
        subtitle = strrep(sprintf('{%s %s}\\rightarrow{%s %s}', string(the_other_switches), status1, string(the_other_switches), status2), '_', '-');
    else
        if state_of_other_switches(1,1)==false
            status1 = 'off';
        else
            status1 = 'on';
        end
        if state_of_other_switches(1,2)==false
            status2 = 'off';
        else
            status2 = 'on';
        end
        if state_of_other_switches(2,1)==false
            status1_2 = 'off';
        else
            status1_2 = 'on';
        end
        if state_of_other_switches(2,2)==false
            status2_2 = 'off';
        else
            status2_2 = 'on';
        end
        subtitle = strrep(sprintf('{%s %s, %s %s}\\rightarrow{%s %s, %s %s}', string(the_other_switches(1,1)), status1, string(the_other_switches(1,2)), status2,...
            string(the_other_switches(1,1)), status1_2, string(the_other_switches(1,2)), status2_2),'_','-');
    end
elseif n_configs==4
    subtitle = 'summary of all regions';
end

% entitle the figure with the name of the switch who's behaviour we're
% plotting
if isempty(title)
    title = {strrep([br_obj(1).behaviour.Properties.VariableNames{:},' bifurcation diagram'], '_', '-');subtitle};
end
ax.Title.String = title;

switch_subject = br_obj(1).behaviour.Properties.VariableNames{:};

% Track axis limits from polygon vertices; keep handles for optional
% output.
XYMax = [0, 0];
num_label = 1;

% make vector for polygon objects to be handed back to the caller
h = [];
for i=1:length(br_obj)
    h = [h,plot(ax, br_obj(i).polygon)];
    
    % shade in the regions using hatching, stripes or speckles if asked
    if ~isempty(hatchfillParams)
        if strcmp('speckle',hatchfillParams{i,1})
            hatchfill(h(i), hatchfillParams{i,1});
        else
            hatchfill(h(i), hatchfillParams{i,:});
        end
    end
    
    % add text labels to each region
    [x, y] = centroid(br_obj(i).polygon);
    if height(br_obj(i).behaviour)==4 || height(br_obj(i).behaviour)==2
        label = string(num_label);
        num_label = num_label + 1;
    else
        label = br_obj(i).behaviour.(switch_subject);
    end
    text(ax, x, y, label,...
            'interpreter', 'latex',...
            'FontSize', 14,...
            'BackgroundColor', 'w',...
            'HorizontalAlignment', 'center',...
            'VerticalAlignment', 'middle');
    XYMax = max([XYMax;br_obj(i).polygon.Vertices]);
end
ax.XLim = [0, XYMax(1)];
ax.YLim = [0, XYMax(2)];
fig = ax.Parent;
if nargout==2
    varargout{1} = h;
end
end