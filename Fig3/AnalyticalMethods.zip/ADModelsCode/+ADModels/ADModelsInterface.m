classdef ADModelsInterface
    
    properties ( Abstract, Constant = true, Access = public ) % these properties will be publicly visible but unchangeable
        parameterNames {iscell}
        stateNames {iscell}
        switchNames {iscell}
        equations {iscell}
    end
    
    properties ( Abstract, Dependent = true )
        steadyStates{istable} % this must provide the steady states at the current parameter values on the model_object
    end
    
    properties ( Access = public ) % these properties will be publicly visible
        parameters {istable}
        switchStates {istable}
    end
    
    properties ( Access = protected ) % these properties will be private, but accessible by any subclass methods
        initialStates {istable}
    end
    
    methods ( Abstract, Access = public )
        % Subclasses must implement these core model operations.

        [times, states, tSw, ySw] = simulate ( m, times, varargin )
        
        % method to calculate the behaviours of each of the switches
        [behaviours, varargout] = get_behaviours ( m, varargin )

        % method to calculate the steady states of each of the continuous-valued state variables given a table of switch states
        steadyStates = get_steadyStates ( m, switchStates )

    end
    
    methods
        function m = set.parameters ( m, parameters )
            % Check parameters is a table containing each of the required
            % parameters

            if isstruct (parameters)
                parameters = struct2table (parameters);
            end
            if (istable(parameters))
                present = ismember ( m.parameterNames, parameters.Properties.VariableNames );
                if ( sum(present) ~= length(m.parameterNames) ) % if not all parameters are accounted for
                    error(['Parameter(s) [', strjoin(m.parameterNames(~present),', '), '] did not appear in the parameter table you provided. Please provide these.']);
                end
                present = ismember ( parameters.Properties.VariableNames, m.parameterNames );
                if ( sum(present) ~= length(parameters.Properties.VariableNames) ) % if some of the specified parameters do not appear in the parameterNames list
                    error(['The following specified parameter(s) [', strjoin(parameters.Properties.VariableNames(~present),', '), '] are not parameters of this model (m.parameterNames to see the list).']);
                end
                if any ( parameters{:,:} < 0 )
                    error ( 'set.parameters:errorNegative', 'All parameters must be positive' );
                end
                m.parameters = parameters;
                
            elseif ( isvector( parameters ) && length ( parameters ) == length ( m.parameterNames ) ) % if we're just setting the parameters values.
                if any ( parameters < 0 )
                    error ( 'set.parameters:errorNegative', 'All parameters must be positive' );
                end
                m.parameters { 1, m.parameterNames } = parameters;
            end
        end
        
        function m = set.initialStates ( m, initialStates )
            % Check y0 is a table or vector containing each of the required
            % state initial values. If only F is specified, we calculate
            % the remaining variables as those at steady state.
            if isstruct (initialStates)
                initialStates = struct2table (initialStates);
            end
            if ( istable( initialStates ) )
                present = ismember(m.stateNames, initialStates.Properties.VariableNames);
                if ( sum(present) ~=  length(m.stateNames)) % if not all parameters are accounted for
                    error('State(s) [%s] did not appear in the initial initialStates table you provided. Please provide these, or provide F only.',strjoin(m.stateNames(~present),', '));
                else
                    m.initialStates = initialStates;
                end
            elseif ( isvector( initialStates ) )
                if ( length(initialStates) == length(m.stateNames) )
                    initialStatesCell = num2cell ( initialStates );
                    m.initialStates = table(initialStatesCell{:}, ...
                        'VariableNames', m.stateNames);
                else
                    error(['Wrong number of variables in ''initialStates'' vector. The vector should be given as [', strjoin(m.stateNames,', '), '], or given as a table.']);
                end
            else
                error('I need a table or a vector of initial conditions.');
            end
        end
        
        function m = set.switchStates(m, switchStates)
            % function to take in switch states as a struct, table or
            % vector
            
            % Table must contain all switchNames; vector must match length(switchNames).
            if isstruct (switchStates)
                switchStates = struct2table (switchStates);
            end
           
            num_switches = length(m.switchNames);
            if ( istable( switchStates ) )
                present = ismember(m.switchNames, switchStates.Properties.VariableNames);
                if ( sum(present) ~= num_switches ) % if not all parameters are accounted for
                    error(['Switch(es) [', strjoin(m.switchNames(~present),', '), '] did not appear in the initial initialStates table you provided. Please provide these.']);
                end
                m.switchStates = switchStates;
            elseif ( isvector( switchStates ) )
                if ( length(switchStates) ~= num_switches )
                    error('Wrong number of variables in ''switches'' vector. The vector should be given as [''N_switch (true/false)'']');
                end
                switchStatesCell = num2cell ( switchStates );
                m.switchStates = table(switchStatesCell{:},...
                    'VariableNames', m.switchNames);
            else
                error('I need a struct, table or vector of switch states.');
            end
        end
        
        function displayLaTeX ( m, stringIn )
            % prepares raw LaTeX code in a cell array for printing with
            % fprintf and then prints with fprintf
            if ~iscell(stringIn)
                error('we need the equations to come in cells');
            end
            stringOut = ''; % initialise stringOut as an empty string
            expressions = {'[%%]','[\\\\]'}; % note that the regular expression is actually just '[%]' and '[\\]', but we need to escape within the MATLAB string
            replacements= { '%%' , '\\\\'};
            for i=1:length(stringIn) % build up stringOut as we filter through each line of the cell array
                stringOut = [stringOut, regexprep(stringIn{i}, expressions, replacements), '\n'];
            end
            fprintf(stringOut);
        end
        
        %% Gemoetry-based methods used to calculate bifurcation diagrams (focal point analysis)
        function [shapes, turn_off_line, turn_on_line] = calculate_regions(model_obj, x_variable_name, y_variable_name, xRange, yRange, m_on, c_on, m_off, c_off, switchBehaviourPassthrough, switchStates, varargin)
            %CALCULATE_REGIONS Partition a 2D parameter plane into BehaviourRegion polygons.
            % Given two boundary-equilibrium (BE) lines (turn-on / turn-off), this
            % function constructs polyshapes for each qualitative behaviour region
            % (Aoff/Hd/Ac/Aon), then wraps them as BehaviourRegion objects.
            %
            % Convention:
            % - If a BE line is vertical, encode it by m = Inf and store its x-intercept in c.

            
            p = inputParser;
            p.addParameter('check', true, @islogical);
            p.parse(varargin{:});
            check = p.Results.check;
            
            xMin = xRange(1);
            xMax = xRange(2);
            yMin = yRange(1);
            yMax = yRange(2);

            % calculate the ends of the BE bifurcation lines
            turn_off_line = struct('x',[max((yMin-c_off)/m_off, xMin), min((yMax-c_off)/m_off, xMax)], ...
                'y',[max(yMin, m_off*xMin+c_off), min(yMax, m_off*xMax+c_off)]);
            turn_on_line = struct('x',[max((yMin-c_on)/m_on, xMin), min((yMax-c_on)/m_on, xMax)], ...
                'y',[max(yMin, m_on*xMin+c_on), min(yMax, m_on*xMax+c_on)]);

            % import the required system model_object definition, which is used to create the objects at the output
            import Bifurcations.BehaviourRegion;
            
            %% Intersection handling (including vertical-line encoding)
            if isinf(m_on) && ~isinf(m_off) % if the "on" line is vertical, we will have specified the x-intercept in the c_on value (usually the y-intercept)
                x_intercept = c_on;
                y_intercept = m_off*x_intercept + c_off;
                m_off_inf = false;
                m_on_inf = true;
            elseif isinf(m_off) && ~isinf(m_on) % if the "off" line is vertical, we will have specified the x-intercept in the c_off value (usually the y-intercept)
                x_intercept = c_off;
                y_intercept = m_on*x_intercept + c_on;
                m_off_inf = true;
                m_on_inf = false;
            elseif isinf(m_off) && isinf(m_on)
                error('Both bifurcation lines are specified as vertical. Check your working.');
            else
                x_intercept = (c_off - c_on)/(m_on - m_off);
                y_intercept = m_on*x_intercept + c_on;
                m_off_inf = false;
                m_on_inf = false;
            end
            
            % intercept condition
            intercept_negative = x_intercept <= xMin || y_intercept <= yMin; % Intercept in negatve section of plane. If TRUE, there are 3 regions, if FALSE, there are 4 regions.
            % intercept above xMax or yMax
            intercept_too_high = x_intercept >= xMax || y_intercept >= yMax; % Intercept in positive section of plane above our axes limits. If TRUE, our bifurcation diagram will look a bit strange, and have only three regions at most when we expect to see four. In extreme cases, the bifurcation diagram may even have only one or two regions in the plane.
            % gradient condition
            grad_off_greater_than_grad_on = m_off > m_on; % if TRUE, {R B D}, if FALSE {R O D}

            %% Choose consistent line ordering (m1,c1) vs (m2,c2) for polygon logic
            if grad_off_greater_than_grad_on
                % Aoff Hd Aon
                if intercept_too_high
                    m2 = m_off;
                    c2 = c_off;
                    m1 = m_on;
                    c1 = c_on;
                else
                    m1 = m_off;
                    c1 = c_off;
                    m2 = m_on;
                    c2 = c_on;
                end
            else
                % Aoff Ac Aon
                if intercept_too_high
                    m1 = m_off;
                    c1 = c_off;
                    m2 = m_on;
                    c2 = c_on;
                else
                    m2 = m_off;
                    c2 = c_off;
                    m1 = m_on;
                    c1 = c_on;
                end
            end
            % top and bottom of lines at xMin and xMax.
            if isinf(m2)
                yTop2 = Inf;
                yLow2 = -Inf;
                
                yTop1 = m1*xMax + c1;
                yLow1 = m1*xMin + c1;
            elseif isinf(m1)
                yTop1 = Inf;
                yLow1 = -Inf;
                
                yTop2 = m2*xMax + c2;
                yLow2 = m2*xMin + c2;
            else
                yTop2 = m2*xMax + c2;
                yTop1 = m1*xMax + c1;

                yLow2 = m2*xMin + c2;
                yLow1 = m1*xMin + c1;
            end
            
            %% Basic input sanity checks
            % This polygon logic assumes the BE lines intersect the plotting window
            % (or at least cross its boundary). If a line never touches the window,
            % region construction can break.

            if intercept_too_high || intercept_negative
                % BE turning off line intersects the axes at ?
                if isinf(m_off)
                    BE_off_x_intercept = c_off;
                    if (BE_off_x_intercept>xMax || BE_off_x_intercept<0)
                        error('WARNING: The BE turning off line does not cross our region of interest at all. This will cause the region calculation code to break down as it assumes the lines must cross our visual range.');
                    end
                else
                    BE_off_x_intercept = (xMin - c_off)/m_off;
                    if (BE_off_x_intercept>xMax || BE_off_x_intercept<0) && (c_off>yMax || c_off<0)
                        error('WARNING: The BE turning off line does not cross our region of interest at all. This will cause the region calculation code to break down as it assumes the lines must cross our visual range.');
                    end
                end
                
                % BE turning on line intersects the axes at ?
                if isinf(m_on)
                    BE_on_x_intercept = c_on;
                    if (BE_on_x_intercept>xMax || BE_on_x_intercept<0)
                        error('WARNING: The BE turning on line does not cross our region of interest at all. This will cause the region calculation code to break down as it assumes the lines must cross our visual range.');
                    end
                else
                    BE_on_x_intercept = (xMin - c_on)/m_on;
                    if (BE_on_x_intercept>xMax || BE_on_x_intercept<0) && (c_on>yMax || c_on<0)
                        error('WARNING: The BE turning on line does not cross our region of interest at all. This will cause the region calculation code to break down as it assumes the lines must cross our visual range.');
                    end
                end
            end

            % Parallel BE lines => region segmentation undefined here.
            if m_on == m_off % lines are parallel
                error('WARNING: The lines are parallel. This isn'' impossible, but it''s weird! Check your work.');
            end
            
            %% Build region polygons
            % categorise the bifurcation diagrams according to the intercept condition
            if m_on_inf 
                % sometimes, the BE lines have infinite gradient, which effectively causes all the cartesian definitions of the locations of the vertices to break down. We must deal with these separately.
                % the m1 line has infinite gradient
                % Layout (conceptual):
                %y^
                % |     |
                % |  R  |   W
                % |-----+------
                % |     |
                % |  V  |   D
                % +------------>
                %              x
                R1 = [xMin, yMax];
                D1 = [xMax, yMin];
                
                if yTop2<yMax
                    W1 = [xMax, yMax];
                    W2 = [x_intercept, yMax];
                    W4 = [xMax, yTop2];
                    D2 = [];
                elseif yTop2>=yMax
                    W1 = [];
                    W2 = [x_intercept, yMax];
                    W4 = [(yMax - c2)/m2, yMax];
                    D2 = [xMax, yMax];
                end
                R5 = W2;
                D3 = W4;
                
                % Intersection point (shared corner)
                R4   = [x_intercept, y_intercept];
                W3 = [x_intercept, y_intercept];
                V3 = [x_intercept, y_intercept];
                D4   = [x_intercept, y_intercept];
                
                if yLow2>yMin
                    V1 = [xMin, yMin];
                    V4 = [xMin, c2];
                    V2 = [x_intercept, yMin];
                    R2 = [];
                elseif yLow2<=yMin
                    V1 = [];
                    V2 = [x_intercept, yMin];
                    V4 = [(yMin-c2)/m2, yMin];
                    R2 = [xMin, yMin];
                end
                R3 = V4;
                D5 = V2;
                
                % Construct polygons for each region
                R = polyshape([R1; R2; R3; R4; R5]);
                W = polyshape([W1; W2; W3; W4]);
                V = polyshape([V1; V2; V3; V4]);
                D = polyshape([D1; D2; D3; D4; D5]);

            elseif intercept_negative || intercept_too_high 
                % The lines intercept outside of the visual range, there
                % are 3 regions in view.
                % Layout:
                %y^
                % |      /      /
                % |  R  /     /
                % |    / M  /
                % |   /   /   D
                % |  /  /
                % +-+--+------->
                %              x
                R1 = [xMin, yMax];
                D1 = [xMax, yMin];
                
                
                if yTop1>yMax && yTop2<yMax
                    M3 = [xMax, yTop2];
                    M4 = [xMax, yMax];
                    M5 = [(yMax - c1)/m1, yMax];
                    R5 = [];
                    D2 = [];
                elseif yTop1<=yMax
                    M3 = [xMax, yTop2];
                    M4 = [];
                    if yTop2==yTop1 % if the middle section has a vertex on the boundary of the figure
                        M5 = [];
                    else
                        M5 = [xMax, yTop1];
                    end
                    R5 = [xMax, yMax];
                    D2 = [];
                elseif yTop2>yMax
                    M5 = [(yMax - c1)/m1, yMax];
                    M4 = [];
                    if (yMax - c2)/m2==(yMax - c1)/m1 % if the middle section has a vertex on the boundary of the figure
                        M3 = [];
                    else
                        M3 = [(yMax - c2)/m2, yMax];
                    end
                    R5 = [];
                    D2 = [xMax, yMax];
                end
                R4 = M5;
                D3 = M3;
                
                if yLow1>yMin && yLow2<yMin
                    M1 = [xMin, yMin];
                    M2 = [(yMin-c2)/m2, yMin];
                    M6 = [xMin, yLow1];
                    R2 = [];
                    D5 = [];
                elseif yLow2>=yMin
                    M1 = [];
                    M6 = [xMin, yLow1];
                    if yLow2==yLow1 % if the middle section has a vertex on the boundary of the figure
                        M2 = [];
                    else
                        M2 = [xMin, yLow2];
                    end
                    R2 = [];
                    D5 = [xMin, xMin];
                elseif  yLow1<yMin
                    M1 = [];
                    M2 = [(yMin-c2)/m2, yMin];
                    if c2/m2==c1/m1 % if the middle section has a vertex on the boundary of the figure
                        M6 = [];
                    else
                        M6 = [(yMin-c1)/m1, yMin];
                    end
                    R2 = [xMin, yMin];
                    D5 = [];
                end
                R3 = M6;
                D4 = M2;
                
                % Construct polygons for each region
                R = polyshape([R1; R2; R3; R4; R5]);
                M = polyshape([M1; M2; M3; M4; M5; M6]);
                D = polyshape([D1; D2; D3; D4; D5]);

            else 
                % The lines intercept within the visual range. There are 4
                % regions in view.
                % Layout:
                %y^
                % |     |
                % |  R  |   W
                % |-----+------
                % |     |
                % |  V  |   D
                % +------------>
                %              x
                R1 = [xMin, yMax];
                D1 = [xMax, yMin];
                
                if yTop1>yMax && yTop2<yMax
                    W1 = [xMax, yMax];
                    W2 = [(yMax - c1)/m1, yMax];
                    W4 = [xMax, yTop2];
                    R6 = [];
                    D2 = [];
                elseif yTop1<=yMax
                    W1 = [];
                    W2 = [xMax, yTop1];
                    W4 = [xMax, yTop2];
                    R6 = [xMax, yMax];
                    D2 = [];
                elseif yTop2>yMax
                    W1 = [];
                    W2 = [(yMax - c1)/m1, yMax];
                    W4 = [(yMax - c2)/m2, yMax];
                    R6 = [];
                    D2 = [xMax, yMax];
                end
                R5 = W2;
                D3 = W4;
                
                R4   = [x_intercept, y_intercept];
                W3 = [x_intercept, y_intercept];
                V3 = [x_intercept, y_intercept];
                D4   = [x_intercept, y_intercept];
                
                if yLow2>yMin && yLow1<yMin
                    V1 = [xMin, yMin];
                    V2 = [(yMin-c2)/m2, yMin];
                    V4 = [xMin, yLow1];
                    R2 = [];
                    D6 = [];
                elseif yLow1>=yMin
                    V1 = [];
                    V2 = [xMin, yLow1];
                    V4 = [xMin, yLow2];
                    R2 = [];
                    D6 = [xMin, yMin];
                elseif yLow2<yMin
                    V1 = [];
                    V2 = [(yMin-c1)/m1, yMin];
                    V4 = [(yMin-c2)/m2, yMin];
                    R2 = [xMin, yMin];
                    D6 = [];
                end
                R3 = V4;
                D5 = V2;
                
                %% create a polyshape for each region
                R = polyshape([R1; R2; R3; R4; R5; R6]);
                W = polyshape([W1; W2; W3; W4]);
                V = polyshape([V1; V2; V3; V4]);
                D = polyshape([D1; D2; D3; D4; D5; D6]);
            end
            
            %% labels for each region
            valueset = cellstr({'Aoff','Hd','Ac','Aon'});
            behaviour_Aoff = table(categorical({'Aoff'},valueset),'VariableNames', {switchBehaviourPassthrough});
            behaviour_Hd = table(categorical({'Hd'},valueset),'VariableNames', {switchBehaviourPassthrough});
            behaviour_Ac = table(categorical({'Ac'},valueset),'VariableNames', {switchBehaviourPassthrough});
            behaviour_Aon = table(categorical({'Aon'},valueset),'VariableNames', {switchBehaviourPassthrough});

            %% place each of the polyshapes we've produced into an appropriately labelled behaviour region object
            if intercept_too_high
                if grad_off_greater_than_grad_on % Aoff Ac Aon
                    shapes = [BehaviourRegion(R, x_variable_name, y_variable_name, behaviour_Aoff, switchStates, model_model_obj,'check',check);
                        BehaviourRegion(M, x_variable_name, y_variable_name, behaviour_Ac, switchStates, model_obj,'check',check);
                        BehaviourRegion(D, x_variable_name, y_variable_name, behaviour_Aon, switchStates, model_obj,'check',check)];
                else % Aoff Hd Aon
                    shapes = [BehaviourRegion(R, x_variable_name, y_variable_name, behaviour_Aoff, switchStates, model_obj,'check',check);
                        BehaviourRegion(M, x_variable_name, y_variable_name, behaviour_Hd, switchStates, model_obj,'check',check);
                        BehaviourRegion(D, x_variable_name, y_variable_name, behaviour_Aon, switchStates, model_obj,'check',check)];
                end
            elseif intercept_negative
                if grad_off_greater_than_grad_on % Aoff Hd Aon
                    shapes = [BehaviourRegion(R, x_variable_name, y_variable_name, behaviour_Aoff, switchStates, model_obj,'check',check);
                        BehaviourRegion(M, x_variable_name, y_variable_name, behaviour_Hd, switchStates, model_obj,'check',check);
                        BehaviourRegion(D, x_variable_name, y_variable_name, behaviour_Aon, switchStates, model_obj,'check',check)];
                else % Aoff Ac Aon
                    shapes = [BehaviourRegion(R, x_variable_name, y_variable_name, behaviour_Aoff, switchStates, model_obj,'check',check);
                        BehaviourRegion(M, x_variable_name, y_variable_name, behaviour_Ac, switchStates, model_obj,'check',check);
                        BehaviourRegion(D, x_variable_name, y_variable_name, behaviour_Aon, switchStates, model_obj,'check',check)];
                end
            else
                if grad_off_greater_than_grad_on % Aoff Hd Ac Aon (W=B, V=O). [We analytically found that this situation is not ever possible for the RK-switch].
                    shapes = [BehaviourRegion(R, x_variable_name, y_variable_name, behaviour_Aoff, switchStates, model_obj,'check',check);
                        BehaviourRegion(W, x_variable_name, y_variable_name, behaviour_Hd, switchStates, model_obj,'check',check);
                        BehaviourRegion(V, x_variable_name, y_variable_name, behaviour_Ac, switchStates, model_obj,'check',check);
                        BehaviourRegion(D, x_variable_name, y_variable_name, behaviour_Aon, switchStates, model_obj,'check',check)];
                else % Aoff Ac Hd Aon (W=O, V=B)
                    shapes = [BehaviourRegion(R, x_variable_name, y_variable_name, behaviour_Aoff, switchStates, model_obj,'check',check);
                        BehaviourRegion(W, x_variable_name, y_variable_name, behaviour_Ac, switchStates, model_obj,'check',check);
                        BehaviourRegion(V, x_variable_name, y_variable_name, behaviour_Hd, switchStates, model_obj,'check',check);
                        BehaviourRegion(D, x_variable_name, y_variable_name, behaviour_Aon, switchStates, model_obj,'check',check)];
                end
            end
        end

        %% overlap_regions
        function shapes = overlap_regions(model_obj, shapes_off, shapes_on, varargin)
            % method to calculate and assign labels to the overlaps between two
            % bifurcation diagrams
            
            p = inputParser;
            p.addParameter('check', true, @islogical);
            p.parse(varargin{:});
            check = p.Results.check;
            
            %% import the required system model_object definition
            import Bifurcations.BehaviourRegion;

            %% Find which regions overlap
            n_off_shapes = length(shapes_off);
            n_on_shapes  = length(shapes_on);
            
            k = 1;
            for off_s = 1:n_off_shapes
                for on_s = 1:n_on_shapes
                    if overlaps(shapes_off(off_s).polygon,shapes_on(on_s).polygon)
                        shapes(k) = BehaviourRegion(intersect(shapes_off(off_s).polygon,shapes_on(on_s).polygon),...
                            shapes_off(off_s).x_variable_name,...
                            shapes_off(off_s).y_variable_name,...
                            [shapes_off(off_s).behaviour;shapes_on(on_s).behaviour],...
                            [shapes_off(off_s).switchStates;shapes_on(on_s).switchStates],...
                            model_obj, 'check',check);
                        k = k + 1;
                    end
                end
            end
            shapes = shapes'; % make it column-wise for consistency.
        end
        %%
    end
end
