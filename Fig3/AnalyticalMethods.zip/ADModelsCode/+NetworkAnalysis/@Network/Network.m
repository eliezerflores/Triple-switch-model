classdef Network
    %NETWORK Class to represent switch state configuration networks
    % Keeps track of the assumptions made regarding switch
    % timescales, and stores a transition matrix F over the 8 binary switch configurations
    % (RK, T, D), and summarises dynamical structure (absorbing states/loops,
    % transient loops). Optionally retains the parameter-space polygons and
    % model parameters for traceability/plotting.


    properties
        F (8,8) double % Deterministic transition matrix for this network (one-step updates).
        
        to_plot (8,1) logical = ones(8,1); % Mask for hiding nodes in plots
        
        weight (1,1) double % Fraction of parameter-region volume assignes to this network (race-resolution weight).
        
        average_F (8,8) double % Unsolved transition matrix before choosing race winners.
        
        switchOrder table % Race-resolution ordering for {RK,T,D} (1=first, 2=second, 3=third, NaN=no race).

        RK_polygon (1,1) polyshape % RK-plane polygon for the underlying behaviour region.
        D_polygon (1,1) polyshape % D-plane polygon for the underlying behaviour region.
        
        parameters (1,:) table % ODE parameters at region centroid.
        switchValues table % Switch thresholds used by the model.
        RFunction table % table of values for the R-switch at each state (off or on)
        KFunction table % table of values for the K-switch at each state (off or on)
        TFunction table % table of values for the T-switch at each state (off, or on)
        DFunction table % table of values for the D-switch at each state (off or on)
        
        % --- Derived structural summaries (computed in classify()) ---
        num_absorbing_states % Count of absorbing single states.
        num_absorbing_loops % Count of absorbing loops (length>1, excluding transient loops).
        num_transient_loops % Count of transient loops (special-case loops that must eventually exit).

        absorbing_states % Vector of absorbing state indices.
        absorbing_loops % Cell array of absorbing cycles (each cell: vector of node indices).
        transient_loops % Cell array of transient 2-cycles.
        transient_loops_table table % Edge table listing transient-loop edges (for plotting/removal).
        loop_lengths double % Lengths of absorbing loops (excluding transient loops).
        
        classification = table(false, false, false, false, false, 'VariableNames', {'monostable', 'multiStable', 'oscillation', 'multiOscillation', 'stableAndOscillation'});% table consisting of true false beneath the titles monostable, multistable, oscillation
    end
    
    properties (Access=private)
        G % digraph representation of F (used for cycle/path computations)
        
        switchStates = table([0;0;0;0;1;1;1;1],[0;0;1;1;0;0;1;1],[0;1;0;1;0;1;0;1],'VariableNames', {'RK_switch', 'T_switch', 'D_switch'})
        
        transient_loop_exits (8,8) double % Required "exit edges" that break transient loops.
        transient_loop_exits_table table  % Edge table version of transient_loop_exits.

        entry_states cell % For each absorbing loop: nodes that have incoming edges from outside the loop.
    end
    
    methods
        function obj = Network(F, varargin)
            %NETWORK Build an 8-state switch-transition network.

            % parse the inputs to this method
            p = inputParser;
            
            p.addRequired('F', @(x) isnumeric(x) || iscell(x));
            
            p.addOptional('switchOrder', [], @istable);
            
            p.addOptional('behaviourState',[],@(x) isa(x, 'Bifurcations.BehaviourStateTable'));
            
            p.addParameter('average_F', []);
            p.addParameter('weight', []);
            
            p.parse(F, varargin{:});
            
            obj.F = p.Results.F;
            obj.G = digraph(F);
            
            %% Store race-resolution order
            if ~isempty(p.Results.switchOrder)
                obj.switchOrder = p.Results.switchOrder;
            end

            % Attach model/region metadata from
            % BehaviourStateTable
            if ~isempty(p.Results.behaviourState)
                obj.parameters = p.Results.behaviourState.parameters;
                obj.switchValues = p.Results.behaviourState.switchValues;
                obj.RFunction = p.Results.behaviourState.RFunction;
                obj.KFunction = p.Results.behaviourState.KFunction;
                obj.TFunction = p.Results.behaviourState.TFunction;
                obj.DFunction = p.Results.behaviourState.DFunction;
                
                obj.RK_polygon = p.Results.behaviourState.RK_polygon;
                obj.D_polygon  = p.Results.behaviourState.D_polygon;
            end
            % Precompute loop/absorbing-state structure used by downstream
            % analysis.
            obj = classify(obj);
            
            % Store averaged matrix + region weight
            if ~isempty(p.Results.average_F)
                obj.average_F = p.Results.average_F;
                obj.weight = p.Results.weight;
            else
                obj.weight = 1;
            end
        end

        function obj_out = plus(obj1,obj2)
            obj_out = obj1;
            obj_out.F = obj1.F + obj2.F;
        end
        
        function ss = get_switch_states(obj, index)
            % GET_SWITCH_STATES  Return RK/T/D switch bits for state index
            % 1..8
            ss = obj.switchStates(index,:);
        end
        
        fig = plot(obj,varargin)
        
        [XLoc, YLoc] = tree_layout(obj,varargin)
        
        %% distribution plots and tests
        [x, y] = bar_distribution(obj)
        
        %% pathways through the network
        % [stable_end_paths, loop_end_paths, weights] = list_paths(obj)

        out_pths = paths(obj, varargin)
        
        function obj = classify(obj)
            %% calculate network properties for each object we're initialising
            
            for i=1:length(obj(:))
                loops = allcycles(obj(i).G); 
                
                nAbsorbingStates = 0;
                nAbsorbingLoops = 0;
                nTransientLoops = 0;
                
                absorbingStates = [];
                transientLoops = {};
                absorbingLoops = {};
                
                transientLoopsTable = table([],[], 'VariableNames',{'EndNodes','Weight'});
                loopLengths = [];
                
                transient_loop_index = 1;
                
                transientLoopExits = sparse(8,8);
                transientLoopExitsTable = table([],[], 'VariableNames',{'EndNodes','Weight'}); % preallocation
                
                for loop_index=1:length(loops)
                    lngth_this_loop = length(loops{loop_index});

                    if lngth_this_loop==1 % Self-loop: an absorbing state
                        nAbsorbingStates = nAbsorbingStates + 1;
                        absorbingStates = [absorbingStates,loops{loop_index}];

                    elseif lngth_this_loop==2 && (sum(ismember(loops{loop_index}, [3,4]))==2 || sum(ismember(loops{loop_index}, [5,6]))==2)
                        % 2-cycles [3,4] and [5,6] are treated as transient
                        % loops
                        nTransientLoops = nTransientLoops + 1;
                        transientLoops{transient_loop_index} = loops{loop_index};
                        for k=1:length(loops{loop_index})
                            transientLoopsTable = [transientLoopsTable; table([loops{loop_index};flip(loops{loop_index})], [1; 1], 'VariableNames', {'EndNodes', 'Weight'})];
                        end
                        
                        if sum(ismember(loops{loop_index}, [3,4]))==2 % if we're seeing the [3,4] transient loop (called "type 1" in the thesis)
                            transientLoopExits(3, 1) = 1; % we know state 3 must eventually transition to state 1 if it's in a transient loop with state 4
                            transientLoopExits(4, 2) = 1; % we know state 4 must eventually transition to state 2 if it's in a transient loop with state 3
                            thisTransientLoopExitsTable = table([3, 1; 4, 2], [1; 1], 'VariableNames', {'EndNodes', 'Weight'});
                        elseif sum(ismember(loops{loop_index}, [5,6]))==2 % if we're seeing the [5,6,] transient loop (called "type 2" in the thesis)
                            transientLoopExits(5, 7) = 1; % we know state 5 must eventually transition to state 7 if it's in a transient loop with state 6
                            transientLoopExits(6, 8) = 1; % we know state 6 must eventually transition to state 8 if it's in a transient loop with state 5
                            thisTransientLoopExitsTable = table([5, 7; 6, 8], [1; 1], 'VariableNames', {'EndNodes', 'Weight'});
                        end

                        transientLoopExitsTable = [transientLoopExitsTable; thisTransientLoopExitsTable];
                        transient_loop_index = transient_loop_index + 1;
                    else
                        % Any other cycle is treated as an absorbing loop
                        nAbsorbingLoops = nAbsorbingLoops + 1;
                        absorbingLoops = [absorbingLoops,loops{loop_index}];
                        loopLengths = [loopLengths,lngth_this_loop];
                        
                        % entry nodes are loop nodes with incoming edges from outside the loop
                        is_entry_node = indegree(obj(i).G,loops{loop_index})'>1; % find which node(s) in the loop are the entry node(s).
                        obj(i).entry_states{loop_index} = loops{loop_index}(is_entry_node);
                        
                    end
                end
                obj(i).num_absorbing_states = nAbsorbingStates;
                obj(i).num_absorbing_loops = nAbsorbingLoops;
                obj(i).num_transient_loops = nTransientLoops;
                
                obj(i).absorbing_states = absorbingStates;
                obj(i).absorbing_loops = absorbingLoops;
                obj(i).transient_loops = transientLoops;
                obj(i).transient_loops_table = transientLoopsTable;
                obj(i).transient_loop_exits = transientLoopExits;
                obj(i).transient_loop_exits_table = transientLoopExitsTable;
                
                obj(i).loop_lengths = loopLengths;
                
            end
        end
        
        function lngth = max_loop_length(obj)
            % MAX_LOOP_LENGTH Return maximum absorbing-loop length (or 1 if
            % none).
            lngth = size(obj);
            for i=1:length(obj(:))
                max_lngth = max(obj(i).loop_lengths);
                if isempty(max_lngth)
                    lngth(i) = 1;
                else
                    lngth(i) = max_lngth;
                end
            end
        end

        function tf = eq(obj1, obj2)
            % EQ Exact equality of transition matrices.
            tf = true(size(obj1));
            for obj1Index = 1:length(obj1)
                if full(sum(obj1(obj1Index).F~=obj2.F, 'all'))
                    continue;
                end
            end
        end


        function tf = ne(obj1, obj2)
            % NE Logical negation of eq().
            tf = ~eq(obj1,obj2);
        end
    end
    

    methods (Access=private)
        % illustration functions
        circ = circle(obj, x, y, radius_x, radius_y)
        ax = switch_state_circles(obj, ax, xLoc, yLoc, width, switchState, to_plot, label_circles, font_size)
        ax = label_nodes(obj, ax, XLoc, YLoc, width, nodeLabels)
    end
end