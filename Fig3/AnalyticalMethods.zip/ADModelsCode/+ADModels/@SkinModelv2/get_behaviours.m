function [behaviours, varargout] = get_behaviours ( m, varargin )
% get_behaviours Determine qualitative behaviours of model switches
% (Aoff, Hd, Ac, Aon)

if nargin<2 % note we always have at least one argument in, which is the model object m.
    % If no second argument is provided, (we assume the user wants to know about all the possible switch
    % states) create a default table containing all possible combinations
    % of switch states.
    switchStates = table([false;false;false;false;true;true;true;true],...
        [false;false;true;true;false;false;true;true],...
        [false;true;false;true;false;true;false;true],...
        'VariableNames', {'RK_switch', 'T_switch', 'D_switch'});
else
    switchStates = varargin{1};
end

% Check if the user requested the switchStates table as an output.
if nargout>1 % If so, provide this to the user for easy comparison.
    varargout{1} = switchStates;
end

cats = {'Aoff','Hd','Ac','Aon'}; % four possible behaviour categories
behavs = zeros(1, 3);

behaviours = table([],[],[],...
    'VariableNames', {'RK_switch', 'T_switch', 'D_switch'});

for i=1:height(switchStates)
    
    %% RK-switch
    % Compare steady-state M values (RK on/off) to thresholds M- and M+
    % to classify behaviour
    Mminus = m.switchValues.RK_switch(1,1);
    Mplus  = m.switchValues.RK_switch(1,2);
    
    RKSwitchStates = switchStates(i,:);
    
    RKSwitchStates.RK_switch = true;
    yS_RK_on  = m.get_steadyStates ( RKSwitchStates );
    
    RKSwitchStates.RK_switch = false;
    yS_RK_off = m.get_steadyStates ( RKSwitchStates );
    
    if yS_RK_on.M > Mminus
        if yS_RK_off.M < Mplus
            behavs(1) = 2; % Hd
        else
            behavs(1) = 4; % Aon
        end
    else
        if yS_RK_off.M < Mplus
            behavs(1) = 1; % Aoff
        else
            behavs(1) = 3; % Ac
        end
    end
    
    %% T-switch
    % Currently assumed to behave identically to the RK-switch.
    behavs(2) = behavs(1);
    
    %% D-switch
    % D-switch thresholds depend on the joint state of RK and T switches.
    try isnan(switchStates(i,:).T_switch);
    catch
        disp('debug');
    end
    if isnan(switchStates(i,:).T_switch)
        n = '00';
    else
        if switchStates(i,:).RK_switch && switchStates(i,:).T_switch % if both RK- and T-switch are on
            n = '11';
        elseif ~switchStates(i,:).RK_switch && switchStates(i,:).T_switch % if only T-switch is on
            n = '01';
        elseif switchStates(i,:).RK_switch && ~switchStates(i,:).T_switch % if only RK-switch is on
            n = '10';
        else % if neither RK- nor T-switch are on
            n = '00';
        end
    end

    % Classify D-switch behaviour by comparing steady-state B values
    % against D-switch thresholds B- and B+
    Bminus = m.switchValues.D_switch(n,1);
    Bplus  = m.switchValues.D_switch(n,2);
    
    DSwitchStates = switchStates(i,:);
    
    DSwitchStates.D_switch = true;
    yS_D_on  = m.get_steadyStates ( DSwitchStates );
    
    DSwitchStates.D_switch = false;
    yS_D_off = m.get_steadyStates ( DSwitchStates );
    
    if yS_D_on.B > Bminus
        if yS_D_off.B < Bplus
            behavs(3) = 2; % Hd
        else
            behavs(3) = 4; % Aon
        end
    else
        if yS_D_off.B < Bplus
            behavs(3) = 1; % Aoff
        else
            behavs(3) = 3; % Ac
        end
    end
    
    behaviours_vec = categorical(behavs, 1:4, cats);
    
    behaviours = [behaviours;table(behaviours_vec(:,1),behaviours_vec(:,2),behaviours_vec(:,3),...
        'VariableNames', {'RK_switch', 'T_switch', 'D_switch'})];
end
end