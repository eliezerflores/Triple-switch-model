function outputstruct = regions_D_switch(obj, kappa_B_range, delta_B_range, varargin)
% regions_D_switch Method to calculate the behaviour regions of
% the D-switch bifurcation diagram

% NOTE: different from the other switches, the D-switch "turn on" means to 
% transition from unhealthy to healthy, and to "turn off" is to transition from healthy to unhealthy.

p = inputParser;
p.addParameter('check', true, @islogical);
p.parse(varargin{:});
check = p.Results.check;

% Name the threshold values and switch values as variables within the scope
% of this function for clarity. (We could refer to each of these through the
% object, but it would be more difficult to read and maintain the code.)

D_off = obj.DFunction.off;
D_on = obj.DFunction.on;

R_off = obj.RFunction.off;
R_on  = obj.RFunction.on;
K_off = obj.KFunction.off;
K_on  = obj.KFunction.on;
T_off = obj.TFunction.off;
T_on  = obj.TFunction.on;

% Format for the D-switch thresholds: Bminus_RK_T and Bplus_RK_T
% D-switch thresholds depend on the states of R and T, '01' etc represent
% the corresponding RK, T states.
Bminus_0_0 = obj.switchValues.D_switch('00', 1);
Bminus_0_1 = obj.switchValues.D_switch('01', 1);
Bminus_1_0 = obj.switchValues.D_switch('10', 1);
Bminus_1_1 = obj.switchValues.D_switch('11', 1);
Bplus_0_0  = obj.switchValues.D_switch('00', 2);
Bplus_0_1  = obj.switchValues.D_switch('01', 2);
Bplus_1_0  = obj.switchValues.D_switch('10', 2);
Bplus_1_1  = obj.switchValues.D_switch('11', 2);

%% calculate bifurcation diagram with D_off with RK-switch off and T-switch off
% BE line for D-switch off --> on
[m_turn_on_R_off_T_off, c_turn_on_R_off_T_off]   = obj.BE_line_D_plane(R_off,K_off,T_off,D_off,Bplus_0_0);

% BE line for D-switch on --> off
[m_turn_off_R_off_T_off, c_turn_off_R_off_T_off] = obj.BE_line_D_plane(R_off,K_off,T_off,D_on,Bminus_0_0);

%% calculate bifurcation diagram with D_off with RK-switch off and T-switch on
% BE line for D-switch off --> on
[m_turn_on_R_off_T_on, c_turn_on_R_off_T_on]   = obj.BE_line_D_plane(R_off,K_off,T_on,D_off,Bplus_0_1);

% BE line for D-switch on --> off
[m_turn_off_R_off_T_on, c_turn_off_R_off_T_on] = obj.BE_line_D_plane(R_off,K_off,T_on,D_on,Bminus_0_1);

%% calculate bifurcation diagram with D_off with RK-switch on and T-switch off
% BE line for D-switch off --> on
[m_turn_on_R_on_T_off, c_turn_on_R_on_T_off]   = obj.BE_line_D_plane(R_on,K_on,T_off,D_off,Bplus_1_0);

% BE line for D-switch on --> off
[m_turn_off_R_on_T_off, c_turn_off_R_on_T_off] = obj.BE_line_D_plane(R_on,K_on,T_off,D_on,Bminus_1_0);

%% calculate bifurcation diagram with D_off with RK-switch on and T-switch on
% BE line for D-switch off --> on
[m_turn_on_R_on_T_on, c_turn_on_R_on_T_on]   = obj.BE_line_D_plane(R_on,K_on,T_on,D_off,Bplus_1_1);

% BE line for D-switch on --> off
[m_turn_off_R_on_T_on, c_turn_off_R_on_T_on] = obj.BE_line_D_plane(R_on,K_on,T_on,D_on,Bminus_1_1);

%% calculate bifurcation diagram with R_off T_off
switchStates_RK_off_T_off = table(false, false, 'VariableNames', {'RK_switch', 'T_switch'});
[shapes_R_off_T_off, turn_off_R_off_D_off, turn_on_R_off_D_off]  = obj.calculate_regions('kappa_B','delta_B',kappa_B_range, delta_B_range, m_turn_on_R_off_T_off, c_turn_on_R_off_T_off, m_turn_off_R_off_T_off, c_turn_off_R_off_T_off, 'D_switch', switchStates_RK_off_T_off, 'check', check);
%% calculate bifurcation diagram with R_off T_on
switchStates_RK_off_T_on = table(false, true, 'VariableNames', {'RK_switch', 'T_switch'});
[shapes_R_off_T_on, turn_off_R_off_D_on, turn_on_R_off_D_on]   = obj.calculate_regions('kappa_B','delta_B',kappa_B_range, delta_B_range, m_turn_on_R_off_T_on, c_turn_on_R_off_T_on, m_turn_off_R_off_T_on, c_turn_off_R_off_T_on, 'D_switch', switchStates_RK_off_T_on, 'check', check);
%% calculate bifurcation diagram with R_on T_off
switchStates_RK_on_T_off = table(true, false, 'VariableNames', {'RK_switch', 'T_switch'});
[shapes_R_on_T_off, turn_off_R_on_D_off, turn_on_R_on_D_off]   = obj.calculate_regions('kappa_B','delta_B',kappa_B_range, delta_B_range, m_turn_on_R_on_T_off, c_turn_on_R_on_T_off, m_turn_off_R_on_T_off, c_turn_off_R_on_T_off, 'D_switch', switchStates_RK_on_T_off, 'check', check);
%% calculate bifurcation diagram with R_on T_on
switchStates_RK_on_T_on = table(true, true, 'VariableNames', {'RK_switch', 'T_switch'});
[shapes_R_on_T_on, turn_off_R_on_D_on, turn_on_R_on_D_on]    = obj.calculate_regions('kappa_B','delta_B',kappa_B_range, delta_B_range, m_turn_on_R_on_T_on, c_turn_on_R_on_T_on, m_turn_off_R_on_T_on, c_turn_off_R_on_T_on, 'D_switch', switchStates_RK_on_T_on, 'check', check);

%% calculate the polygons for the bifurcation diagram representing the change when the other switch turns on
shapes_overlap_T_off = obj.overlap_regions(shapes_R_off_T_off, shapes_R_on_T_off,'check',check);
shapes_overlap_T_on  = obj.overlap_regions(shapes_R_off_T_on, shapes_R_on_T_on,'check',check);
shapes_overlap  = obj.overlap_regions(shapes_overlap_T_off, shapes_overlap_T_on,'check',check);
outputstruct = struct('RK_off_T_off', shapes_R_off_T_off,...
                    'RK_off_T_on', shapes_R_off_T_on,...
                    'RK_on_T_off', shapes_R_on_T_off,...
                    'RK_on_T_on', shapes_R_on_T_on,...
                    'overlap', shapes_overlap, ...
                    ...
        'turn_on_R_off_D_off', turn_on_R_off_D_off, ...
        'turn_off_R_off_D_off', turn_off_R_off_D_off, ...
        'turn_on_R_off_D_on', turn_on_R_off_D_on, ...
        'turn_off_R_off_D_on', turn_off_R_off_D_on, ...
        ...
        'turn_on_R_on_D_off', turn_on_R_on_D_off, ...
        'turn_off_R_on_D_off', turn_off_R_on_D_off, ...
        'turn_on_R_on_D_on', turn_on_R_on_D_on, ...
        'turn_off_R_on_D_on', turn_off_R_on_D_on);
end