%% load parameter sets and build a model instance
% Reg_parameter_sets.mat should define p1,p2,p3,p4 (structs)
load("/Users/adaline901/Desktop/ADmodelsCode/Reg_parameter_sets.mat")

import ADModels.*
m  = SkinModelv2(); % Base model "engine" (ODE + switch logic)

params = {p1, p2, p3, p4}; % Collect parameter sets for compatibility fixes

%% Rename legacy field to match current code naming
% This makes older saved parameter structs compatible with the current
% model
for i = 1:length(params)

    % --- ODE field renaming ---
    params{i}.ODE.delta_C = params{i}.ODE.delta_D;
    params{i}.ODE = rmfield(params{i}.ODE, "delta_D");

    params{i}.ODE.kappa_C = params{i}.ODE.kappa_D;
    params{i}.ODE = rmfield(params{i}.ODE, "kappa_D");

    params{i}.ODE.kappa_M = params{i}.ODE.kappa_P;
    params{i}.ODE = rmfield(params{i}.ODE, "kappa_P");

    params{i}.ODE.alpha_M = params{i}.ODE.alpha_P;
    params{i}.ODE = rmfield(params{i}.ODE, "alpha_P");

    params{i}.ODE.M_ex = params{i}.ODE.P_ex;
    params{i}.ODE = rmfield(params{i}.ODE, "P_ex");

    params{i}.ODE.gamma_MB = params{i}.ODE.gamma_PB;
    params{i}.ODE = rmfield(params{i}.ODE, "gamma_PB");

    params{i}.ODE.delta_M = params{i}.ODE.delta_P;
    params{i}.ODE = rmfield(params{i}.ODE, "delta_P");

    params{i}.ODE.M_env = params{i}.ODE.P_env;
    params{i}.ODE = rmfield(params{i}.ODE, "P_env");

    % --- switchParameters renaming ---
    params{i}.switchParameters.DFunction = params{i}.switchParameters.GFunction;
    params{i}.switchParameters = orderfields(params{i}.switchParameters, [1:4, 8, 5:7]);
    params{i}.switchParameters = rmfield(params{i}.switchParameters, "GFunction");

    params{i}.switchParameters.D_switch = params{i}.switchParameters.G_switch;
    params{i}.switchParameters = orderfields(params{i}.switchParameters, [1:6, 8, 7:7]);
    params{i}.switchParameters = rmfield(params{i}.switchParameters, "G_switch");

    % Keep field order tidy for debugging
    params{i}.switchParameters = orderfields(params{i}.switchParameters);
end

% Unpack back to separtae variables
[p1, p2, p3, p4] = params{:};

%% Choose one parameter set and define scan ranges
m1 = m.set_parameters(p1);


kappa_B_range = [0,1];
delta_B_range = [0,1];
kappa_M_range = [0,30];
alpha_M_range = [0,30];


set(0,'DefaultFigureColor','w'); % Set white background for figures

%% 1) RK-switch bifurcation diagram (in kappa_M-alpha_M plane)
% Output is a struct of BehaviourRegion objects for different Don/off
% cases.
rk_out = m1.regions_RK_switch(kappa_M_range, alpha_M_range, 'check', false);

% With D_off
figure('Color','w'); hold on;
plot(rk_out.D_off);
title('RK-switch regions (D_{off})'); xlabel('\kappa_M'); ylabel('\alpha_M');
axis equal tight;

% With D_on
figure('Color','w'); hold on;
plot(rk_out.D_on);
title('RK-switch regions (D_{on})'); xlabel('\kappa_M'); ylabel('\alpha_M');
axis equal tight;

% Overlap diagram
figure('Color','w'); 
hold on; 
plot(rk_out.D_off); 
plot(rk_out.D_on); % overlay G=on regions 
title('RK-switch bifurcation regions (overlay: D_{off} vs D_{on})') 
xlabel('\kappa_M'); 
ylabel('\alpha_M'); 
ax = gca; 
hold(ax,'on'); 
box(ax,'on');


%% 1) D-switch bifurcation diagram (in kappa_B-delta_B plane)
% Output is a struct of BehaviourRegion objects for different (RK,T) on/off
% cases.
set(0,'DefaultFigureColor','w'); % Set white background

d_out = m1.regions_D_switch(kappa_B_range, delta_B_range, 'check', false); % Choose one parameter set m_i

% With RK_off_T_off
figure('Color','w'); hold on;
plot(d_out.RK_off_T_off);
title('RT_{off} regions'); xlabel('\kappa_B'); ylabel('\delta_B');
axis equal tight;

% With RK_off_T_on
figure('Color','w'); hold on;
plot(d_out.RK_off_T_on);
title('RK_{off} T_{on} regions'); xlabel('\kappa_B'); ylabel('\delta_B');
axis equal tight;

% With RK_on_T_off
figure('Color','w'); hold on;
plot(d_out.RK_on_T_off);
title('RK_{on} T_{off} regions'); xlabel('\kappa_B'); ylabel('\delta_B');
axis equal tight;

% With RK_on_T_on
figure('Color','w'); hold on;
plot(d_out.RK_on_T_on);
title('RT_{on} regions'); xlabel('\kappa_B'); ylabel('\delta_B');
axis equal tight;

% Overlap diagram
figure('Color','w'); 
hold on; 
plot(d_out.RK_off_T_off); 
plot(d_out.RK_on_T_on);
plot(d_out.RK_off_T_on); 
plot(d_out.RK_on_T_off);
title('D-switch bifurcation regions (Overlay: RT on/off)') 
xlabel('\kappa_B'); 
ylabel('\delta_B'); 
ax = gca; 
hold(ax,'on'); 
box(ax,'on');


%% 3) Build BehaviourStateTable objects over overlapping (RK-plane × D-plane) regions
% Each BehaviourStateTable corresponds to one (RK region) × (D region) combination.
[behaviour_state_list1, RK_reg_p1, D_reg_p1] = ...
    Bifurcations.find_behaviourState_regions( ...
        m1, kappa_M_range, alpha_M_range, kappa_B_range, delta_B_range, ...
        'check', false);

% Example: show a "biological view" (D-switch convention flipped)
bst = behaviour_state_list1(1);
bst.viewBioBehaviourState()


%% 4) Convert each BehaviourStateTable into one (or more) Network objects
% Multiple networks can be produced if race conditions exist (different switch orders).
[network_vec1, bs_table_index1, n_networks_produced1] = ...
    NetworkAnalysis.calculate_networks(behaviour_state_list1);  


%% 5) Compute representative paths through each network and visualize as a heatmap
% paths() returns an (8*N) x T matrix: 8 initial configurations per Network.
pths = network_vec1.paths('repeat_absorbing_loops', 2, 'repeat_transient_loops', 2);

% Plot one example network topology
figure;
network_vec1(1).plot('mark_transient_loops', true);
title('Example network for p1');

% Heatmap of state indices over time along each path
figure;
imagesc(pths);
colorbar;
title('Paths of switch networks (p1)');
xlabel('Time step');
ylabel('Path index');

% Label colorbar ticks with 3-bit switch-state strings
% State index 1..8 corresponds to binary 000..111 (RK, T, D).
raw = dec2bin(0:7, 3);
labels = raw;

% Flip the D-switch digit in the label for biological view.
for i = 1:8
    if labels(i,3) == '0'
        labels(i,3) = '1';
    else
        labels(i,3) = '0';
    end
end

% Convert to cell array of strings for labelling
labels_cell = cellstr(labels);
cb = colorbar;
cb.Ticks = 1:8;
cb.TickLabels = labels_cell;